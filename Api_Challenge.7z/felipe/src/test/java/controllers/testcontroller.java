package controllers;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import model.Board;
import model.Card;
import model.List;
import model.Member;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

    public class testcontroller
    {




        public static JsonObject fill_data() throws FileNotFoundException
        {
            JsonObject job_temp;
            String path = "src/test/Resources/json/datos_usar.json";
            BufferedReader bufferedReader = new BufferedReader(new FileReader(path));

            Gson gson = new Gson();

            job_temp = new Gson().fromJson(bufferedReader, JsonObject.class);

            return job_temp;
        }

        public static void check_card_created_1(RequestSpecification requestSpecification, JsonObject jobj, Response response_get_list, Response response_get_card) throws MalformedURLException {
            Response response_create_card;
            if(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString()).equals(""))
            {
                response_create_card=requestSpecification.when().post(testcontroller.create_card_In_ListURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_1").getAsString()),jobj.get("nombre_card").getAsString()));
            }
        }
        public static void check_card_created_2(RequestSpecification requestSpecification, JsonObject jobj, Response response_get_list, Response response_get_card) throws MalformedURLException {
            Response response_create_card;
            if(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString()).equals(""))
            {
                response_create_card=requestSpecification.when().post(testcontroller.create_card_In_ListURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_2").getAsString()),jobj.get("nombre_card").getAsString()));
            }
        }
        public static void check_card_created_3(RequestSpecification requestSpecification, JsonObject jobj, Response response_get_list, Response response_get_card) throws MalformedURLException {
            //Response response_create_card;
            if(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString()).equals(""))
            {
              //  response_create_card=
                        requestSpecification.when().post(testcontroller.create_card_In_ListURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_3").getAsString()),jobj.get("nombre_card").getAsString()));
            }
        }



        public Map<String,String> getAuthParams(JsonObject jobj)
        {

            Map<String,String> params=new HashMap<>();
            params.put("key",jobj.get("api_key").getAsString());
            params.put("token",jobj.get("token").getAsString());
            return params;
        }


        public static String Get_id_Board(Response response,String name_board)
        {
            String id_returned="";
            Gson gson=new Gson();
            Board[] board_tempo = gson.fromJson(response.getBody().asString(), Board[].class);
            for(int i=0;i<board_tempo.length;i++)
            {
                if(board_tempo[i].getName().equals(name_board))
                {
                    id_returned=board_tempo[i].getId();
                }
            }
            return id_returned;
        }

        public static String Get_id_List(Response response_get_list, String name)
        {
            String id_returned="";
            Gson gson=new Gson();
            List[] list_tempo = gson.fromJson(response_get_list.getBody().asString(), List[].class);
            for(int i=0;i<list_tempo.length;i++)
            {

                if(list_tempo[i].getName().equals(name))
                {
                    id_returned=list_tempo[i].getId();

                }
            }
            return id_returned;
        }

        public static String Get_id_Card(Response response_get_card, String name)
        {
            String id_returned="";
            Gson gson=new Gson();
            Card[] card_tempo = gson.fromJson(response_get_card.getBody().asString(), Card[].class);
            for(int i=0;i<card_tempo.length;i++)
            {
                if(card_tempo[i].getName().equals(name))
                {
                    id_returned=card_tempo[i].getId();
                }
            }
            return id_returned;
        }

        public static String Get_id_Member(Response response_get_member, String name)
        {
            String id_returned="";
            Gson gson=new Gson();
            Member[] member_tempo = gson.fromJson(response_get_member.getBody().asString(), Member[].class);
            for(int i=0;i<member_tempo.length;i++)
            {


                if(member_tempo[i].getusername().equals(name))
                {
                    id_returned=member_tempo[i].getId();
                }
            }
            return id_returned;
        }



        public static URL getBoardsURL() throws MalformedURLException
        {
           return new URL("https://api.trello.com/1/members/me/boards?fields=name");
        }

        public static URL getlistURL(String id_board) throws MalformedURLException
        {
            return new URL("https://api.trello.com/1/boards/"+id_board+"/lists?cards=none&fields=name");
        }

        public static URL getCardURL(String id_list) throws MalformedURLException
        {
            return new URL("https://api.trello.com/1/lists/"+id_list+"/cards");
        }


        public static URL create_card_In_ListURL(String ID_list,String name_card) throws MalformedURLException
        {
            return new URL("https://api.trello.com/1/cards?name="+name_card+"&idList="+ID_list+"&keepFromSource=all");
        }

        public static URL get_member_in_cardURL(String id_board) throws MalformedURLException
        {

            return new URL("https://api.trello.com/1/boards/"+id_board+"/members?fields=username");
        }

        public static URL create_member_in_cardURL(String id_card ,String id_member) throws MalformedURLException
        {

            return new URL("https://api.trello.com/1/cards/"+id_card+"/idMembers?value="+id_member);
        }

        public static URL create_comment_in_cardURL(String id_card,String mensaje ) throws MalformedURLException
        {

            return new URL("https://api.trello.com/1/cards/"+id_card+"/actions/comments?text="+mensaje);
        }

        public static URL move_cardURl(String id_card,String id_list ) throws MalformedURLException
        {

            return new URL("https://api.trello.com/1/cards/"+id_card+"/idList?value="+id_list);

        }

        public static URL delete_cardURL(String id_card ) throws MalformedURLException
        {

            return new URL("https://api.trello.com/1/cards/"+id_card);

        }

}
