package model;

public class Member {

    private String id;
    private String username;

    public Member() {
        this.id = "";
        this.username = "";
    }

    public Member(String id, String username) {
        this.id = id;
        this.username = username;
    }



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }



}
