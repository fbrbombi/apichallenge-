package steps;

import com.google.gson.JsonObject;
import controllers.testcontroller;
import cucumber.api.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.hamcrest.Matchers;
import org.junit.Assert;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;

public class Apitestsget {


    private RequestSpecification requestSpecification;
    private Response response,response_get_list,response_create_card,response_get_card,response_add_member,response_get_user_id,response_add_comment;
    private Response response_move_card,response_delete;
    public JsonObject jobj= testcontroller.fill_data();
    @Steps
    private testcontroller Testcontroller=new testcontroller();

    public Apitestsget() throws FileNotFoundException {
    }

    @Given("^the user wants to get id of the challenge board$")
    public void theUserWantsToGetIdOfTheChallengeBoard() throws FileNotFoundException {

        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(Testcontroller.getAuthParams(jobj));
        
    }

    @When("^when the user send a request to get the board id$")
    public void whenTheUserSendARequestToGetTheBoardId() throws MalformedURLException
    {

        response=requestSpecification.when().get(testcontroller.getBoardsURL());
        Assert.assertThat("Error: The status code is not <200>", response.getStatusCode(), Matchers.equalTo(200));
    }


    @Then("^the user gets the ID of the board$")
    public void theUserGetsTheIDOfTheBoard()
    {
        Assert.assertThat("There is no board with that name", testcontroller.Get_id_Board(response, jobj.get("nombre_board").getAsString()),Matchers.not(""));
    }

    @Given("^the user wants to  get the id of the list TODO$")
    public void theUserWantsToGetTheIdOfTheList() throws FileNotFoundException
    {
        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(Testcontroller.getAuthParams(jobj));
    }

    @When("^when the user send a request to get the List id$")
    public void whenTheUserSendARequestToGetTheListId() throws MalformedURLException
    {
        response_get_list=requestSpecification.when().get(testcontroller.getlistURL(testcontroller.Get_id_Board(response,jobj.get("nombre_board").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_get_list.getStatusCode(), Matchers.equalTo(200));
    }
    


    @Then("^the user gets the ID of the list TODO$")
    public void theUserGetsTheIDOfTheLisTODO()
    {
       Assert.assertThat("There is no list  with that name in the board ", testcontroller.Get_id_Board(response_get_list, jobj.get("nombre_lista_1").getAsString()),Matchers.not(""));

    }

    @Given("^the user wants to  create a card in the list TODO$")
    public void theUserWantsToCreateACardInAList() throws FileNotFoundException
    {
        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(Testcontroller.getAuthParams(jobj));
    }

    @And("^the user has the list ID$")
    public void theUserHasTheListID() throws MalformedURLException
    {
        response_get_list=requestSpecification.when().get(testcontroller.getlistURL(testcontroller.Get_id_Board(response,jobj.get("nombre_board").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_get_list.getStatusCode(), Matchers.equalTo(200));
        Assert.assertThat("There is no list  with that name in the board", testcontroller.Get_id_Board(response_get_list, jobj.get("nombre_lista_1").getAsString()),Matchers.not(""));

    }

    @When("^when the user send a request to create a card$")
    public void whenTheUserSendARequestToCreateACard() throws MalformedURLException
    {
        response_create_card=requestSpecification.when().post(testcontroller.create_card_In_ListURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_1").getAsString()),jobj.get("nombre_card").getAsString()));
        Assert.assertThat("Error: The status code is not <200>", response_create_card.getStatusCode(), Matchers.equalTo(200));

    }

    @Then("^A new card is created in the list$")
    public void aNewCardIsCreatedInTheList() throws MalformedURLException
    {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_1").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_get_card.getStatusCode(), Matchers.equalTo(200));
        Assert.assertThat("There is no card  with that name in the list", testcontroller.Get_id_Card(response_get_card, jobj.get("nombre_card").getAsString()),Matchers.not(""));
    }

    @And("^the user has the board ID$")
    public void theUserHasTheBoardID() throws MalformedURLException
    {
        response=requestSpecification.when().get(testcontroller.getBoardsURL());
        Assert.assertThat("Error: The status code is not <200>", response.getStatusCode(), Matchers.equalTo(200));
        Assert.assertThat("There is no board with that name", testcontroller.Get_id_Board(response, jobj.get("nombre_board").getAsString()),Matchers.not(""));

    }

    @And("^the user has the card ID$")
    public void theUserHasTheCardID() throws MalformedURLException
    {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_1").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_get_card.getStatusCode(), Matchers.equalTo(200));
    }

    @Given("^the user wants to add a member to the card Felicidad$")
    public void theUserWantsToAddAMemberToACard() throws FileNotFoundException {
        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(Testcontroller.getAuthParams(jobj));
        
    }

    @When("^when the user send a request to add a member to a card$")
    public void whenTheUserSendARequestToAddAMemberToACard() throws MalformedURLException
    {
        response_add_member=requestSpecification.when().post(testcontroller.create_member_in_cardURL(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString()),testcontroller.Get_id_Member(response_get_user_id,jobj.get("username").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_add_member.getStatusCode(), Matchers.equalTo(200));
    }

    @Then("^A member is added to the card$")
    public void aMemberIsAddedToTheCard() throws MalformedURLException {
       Assert.assertThat("There is no member  with that name in the card", testcontroller.Get_id_Member(response_get_user_id, jobj.get("username").getAsString()),Matchers.not(""));

    }

    @Given("^the user wants to add a comment to a card$")
    public void theUserWantsToAddACommentToACard() throws FileNotFoundException {
        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(Testcontroller.getAuthParams(jobj));
    }

    @When("^when the user send a request to add a comment to a card$")
    public void whenTheUserSendARequestToAddACommentToACard() throws MalformedURLException
    {
        response_add_comment=requestSpecification.when().post(testcontroller.create_comment_in_cardURL(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString()),jobj.get("comentario_1").getAsString()));
        Assert.assertThat("Error: The status code is not <200>", response_add_comment.getStatusCode(), Matchers.equalTo(200));
    }

    @Then("^A comment is added to the card$")
    public void aCommentIsAddedToTheCard()
    {

    }

    @Given("^the user wants to  move a card to a list$")
    public void theUserWantsToMoveACardToAList() throws FileNotFoundException
    {
        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(Testcontroller.getAuthParams(jobj));
    }



    @When("^when the user send a request to move a card$")
    public void whenTheUserSendARequestToMoveACard() throws MalformedURLException
    {
       response_move_card=requestSpecification.when().put(testcontroller.move_cardURl(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString()),testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_2").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_move_card.getStatusCode(), Matchers.equalTo(200));
    }

    @Then("^the card is moved to the list$")
    public void theCardIsMovedToTheList() throws MalformedURLException {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_2").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_get_card.getStatusCode(), Matchers.equalTo(200));
        Assert.assertThat("There is no card  with that name in the list", testcontroller.Get_id_Card(response_get_card, jobj.get("nombre_card").getAsString()),Matchers.not(""));

    }

    @Given("^the user wants to  delete a card to a list$")
    public void theUserWantsToDeleteACardToAList() throws FileNotFoundException {
        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(Testcontroller.getAuthParams(jobj));
        
    }

    @Given("^the user wants to  delete a card$")
    public void theUserWantsToDeleteACard() throws FileNotFoundException
    {
        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(Testcontroller.getAuthParams(jobj));
        
    }

    @When("^when the user send a request to delete a card$")
    public void whenTheUserSendARequestToDeleteACard() throws FileNotFoundException, MalformedURLException
    {
       response_delete=requestSpecification.when().delete(testcontroller.
               delete_cardURL(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString())));
       Assert.assertThat("Error: The status code is not <200>", response_delete.getStatusCode(), Matchers.equalTo(200));
    }

    @Then("^the card is deleted to the list$")
    public void theCardIsDeletedToTheList() throws MalformedURLException {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_3").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_get_card.getStatusCode(), Matchers.equalTo(200));
        Assert.assertThat("There is no card  with that name in the list", testcontroller.Get_id_Card(response_get_card, jobj.get("nombre_card").getAsString()),Matchers.is(""));

    }

    @And("^the user has it's own ID$")
    public void theUserHasItSOwnID() throws MalformedURLException
    {
        response_get_user_id=requestSpecification.when().get(testcontroller.get_member_in_cardURL(testcontroller.Get_id_Board(response,jobj.get("nombre_board").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_get_user_id.getStatusCode(), Matchers.equalTo(200));
    }

    @And("^A comment is added to the card IN PROGRESS$")
    public void aCommentIsAddedToTheCardINPROGRESS() throws MalformedURLException {
        response_add_comment=requestSpecification.when().post(testcontroller.create_comment_in_cardURL(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString()),jobj.get("comentario_2").getAsString()));
        Assert.assertThat("Error: The status code is not <200>", response_add_comment.getStatusCode(), Matchers.equalTo(200));
    }

    @Given("^the user wants to  move a card to a final list$")
    public void theUserWantsToMoveACardToAFinalList() throws FileNotFoundException {
        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(Testcontroller.getAuthParams(jobj));
    }

    @When("^when the user send a request to move a card to DONE$")
    public void whenTheUserSendARequestToMoveACardToDONE() throws MalformedURLException
    {
        response_move_card=requestSpecification.when().put(testcontroller.move_cardURl(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString()),testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_3").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_move_card.getStatusCode(), Matchers.equalTo(200));

    }

    @Then("^the card is moved to the list DONE$")
    public void theCardIsMovedToTheListDONE() throws MalformedURLException {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_3").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_get_card.getStatusCode(), Matchers.equalTo(200));
        Assert.assertThat("There is no card  with that name in the list", testcontroller.Get_id_Card(response_get_card, jobj.get("nombre_card").getAsString()),Matchers.not(""));

    }

    @And("^A comment is added to the card DONE$")
    public void aCommentIsAddedToTheCardDONE() throws MalformedURLException
    {
        response_add_comment=requestSpecification.when().post(testcontroller.create_comment_in_cardURL(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString()),jobj.get("comentario_3").getAsString()));
        Assert.assertThat("Error: The status code is not <200>", response_add_comment.getStatusCode(), Matchers.equalTo(200));
    }

    @And("^the user has the new card ID$")
    public void theUserHasTheNewCardID() throws MalformedURLException
    {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_2").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_get_card.getStatusCode(), Matchers.equalTo(200));

    }


    @And("^the user has the final card ID$")
    public void theUserHasTheFinalCardID() throws MalformedURLException
    {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_3").getAsString())));
        Assert.assertThat("Error: The status code is not <200>", response_get_card.getStatusCode(), Matchers.equalTo(200));

    }


    @But("^the user deletes the card in first list$")
    public void theUserDeletesTheCardInFirstList() throws MalformedURLException {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_1").getAsString())));
        response_delete=requestSpecification.when().delete(testcontroller.delete_cardURL(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString())));
    }

    @But("^the user deletes the card in second list$")
    public void theUserDeletesTheCardInSecondList() throws MalformedURLException {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_2").getAsString())));
        response_delete=requestSpecification.when().delete(testcontroller.delete_cardURL(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString())));

    }



    @And("^the user has created a card in first list$")
    public void theUserHasCreatedACardInFirstList() throws MalformedURLException {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_1").getAsString())));
        testcontroller.check_card_created_1(requestSpecification,jobj,response_get_list,response_get_card);
    }

    @And("^the user has created a card in second list$")
    public void theUserHasCreatedACardInSecondList() throws MalformedURLException {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_2").getAsString())));
        testcontroller.check_card_created_2(requestSpecification,jobj,response_get_list,response_get_card);
    }

    @And("^the user has created a card in third list$")
    public void theUserHasCreatedACardInThirdList() throws MalformedURLException {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_3").getAsString())));
        testcontroller.check_card_created_3(requestSpecification,jobj,response_get_list,response_get_card);
    }

    @But("^the user deletes the card in third list$")
    public void theUserDeletesTheCardInThirdList() throws MalformedURLException {
        response_get_card=requestSpecification.when().get(testcontroller.getCardURL(testcontroller.Get_id_List(response_get_list,jobj.get("nombre_lista_3").getAsString())));
        response_delete=requestSpecification.when().delete(testcontroller.delete_cardURL(testcontroller.Get_id_Card(response_get_card,jobj.get("nombre_card").getAsString())));

    }
}
