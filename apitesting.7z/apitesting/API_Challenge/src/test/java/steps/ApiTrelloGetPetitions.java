package steps;

import controller.TestController;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.hamcrest.Matchers;
import org.junit.Assert;

import java.net.MalformedURLException;


public class ApiTrelloGetPetitions {

    @Steps
    private TestController testController;
    private RequestSpecification requestSpecification;
    private Response response;
    private Response responseList;
    private Response responseCard;
    private Response responseMember;
    private Response responseAddMember;
    private Response responseCreateCard;
    private Response responseMembersCard;
    private Response responseCommentsCard;
    private Response responseAddComment;
    private Response responseMoveCard;


     @Given("^David wants to know the content in the board$")
    public void davidWantsToKnowTheContentInTheBoard() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @When("^The user sends the petition for get into the board$")
    public void theUserSendsThePetitionForGetIntoTheBoard() throws MalformedURLException {
        response = requestSpecification.when().get(testController.getUrlMethod().getIdBoardUrl());
        Assert.assertThat("Error: The status code is not <200>", response.getStatusCode(), Matchers.equalTo(200));
    }

    @Then("^The Trello API should response only with the descriptions of the boards that David has$")
    public void theTrelloAPIShouldResponseOnlyWithTheDescriptionsOfTheBoardsThatDavidHas() {
        testController.idBoard(response, "API Challenge 19");

        Assert.assertThat("There is not id board with the name API Challenge 19", testController.idBoard(response, "API Challenge 19"), Matchers.not(""));

     }

    @Given("^David wants to know the lists of the board$")
    public void davidWantsToKnowTheListsOfTheBoard() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());

    }

    @And("^has the board id$")
    public void hasTheBoardId() throws MalformedURLException {
        response = requestSpecification.when().get(testController.getUrlMethod().getIdBoardUrl());
        Assert.assertThat("Error: The status code is not <200>", response.getStatusCode(), Matchers.equalTo(200));
    }

    @When("^He sends the petition for get the list of the board$")
    public void heSendsThePetitionForGetTheListOfTheBoard() throws MalformedURLException {
        theUserSendsThePetitionForGetIntoTheBoard();
         responseList = requestSpecification.when().get(testController.getUrlMethod().getIdListUrl(testController.idBoard(response, "API Challenge 19")));
        Assert.assertThat("Error: The status code is not <200>", responseList.getStatusCode(), Matchers.equalTo(200));

    }

    @Then("^The Trello API should response only with the lists of the board$")
    public void theTrelloAPIShouldResponseOnlyWithTheListsOfTheBoard() {
        Assert.assertThat("There is not id list with the name TODO", testController.idLists(responseList, "TODO"), Matchers.not(""));
    }

    //Create the card

    @Given("^David wants to create a card in the list TODO$")
    public void davidWantsToCreateACardInTheListTODO() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());

    }

    @And("^has the TODO list id$")
    public void hasTheListId() throws MalformedURLException {
        responseList = requestSpecification.when().get(testController.getUrlMethod().getIdListUrl(testController.idBoard(response, "API Challenge 19")));
        Assert.assertThat("Error: The status code is not <200>", responseList.getStatusCode(), Matchers.equalTo(200));
    }

    @When("^He sends the request to post the card on the list$")
    public void heSendsTheRequestToPostTheCardOnTheList() throws MalformedURLException {
        responseCreateCard = requestSpecification.when().post(testController.postUrlMethod().postCard(testController.idLists(responseList, "TODO"), "Valores Endava", "En esta tarjeta encontrará los valores de Endava"));
        Assert.assertThat("Error: The status code is not <200>", responseCreateCard.getStatusCode(), Matchers.equalTo(200));
    }


    @Then("^The Trello API creates the card and takes the id Card$")
    public void theTrelloAPICreatesTheCardAndTakesTheIdCard() throws MalformedURLException {
        responseCard = requestSpecification.when().get(testController.getUrlMethod().getIdCard(testController.idLists(responseList, "TODO")));
        Assert.assertThat("Error: The status code is not <200>", responseCard.getStatusCode(), Matchers.equalTo(200));
        testController.idCard(responseCard, "Valores Endava");
        Assert.assertThat("There is not card with the name Valores Endava", testController.idCard(responseCard, "Valores Endava"), Matchers.not(""));
    }

    @Given("^David wants to add a member in the card Valores Endava$")
    public void davidWantsToAddAMemberInTheCardValoresEndava() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());

    }

    @And("^has the card id$")
    public void hasTheCardId() throws MalformedURLException {
        responseCard = requestSpecification.when().get(testController.getUrlMethod().getIdCard(testController.idLists(responseList, "TODO")));
        Assert.assertThat("Error: The status code is not <200>", responseCard.getStatusCode(), Matchers.equalTo(200));

    }


    @And("^has the member id$")
    public void hasTheMemberId() throws MalformedURLException {
        responseMember = requestSpecification.when().get(testController.getUrlMethod().getIdMember(testController.idBoard(response, "API Challenge 19")));
        Assert.assertThat("Error: The status code is not <200>", responseMember.getStatusCode(), Matchers.equalTo(200));
        Assert.assertThat("There is not id member with the username silvanapareja1 in this board", testController.idMember(responseMember, "silvanapareja1"), Matchers.not(""));
    }

    @When("^He sends the request to add a member$")
    public void heSendsTheRequestToAddAMember() throws MalformedURLException {
        responseAddMember = requestSpecification.when().post(testController.postUrlMethod().postMember(testController.idCard(responseCard, "Valores Endava"), testController.idMember(responseMember, "silvanapareja1")));
        Assert.assertThat("Error: The status code is not <200>", responseAddMember.getStatusCode(), Matchers.equalTo(200));
    }

    @Then("^The Trello API adds a member to the card Valores Endava$")
    public void theTrelloAPIAddsAMemberToTheCardValoresEndava() throws MalformedURLException {
        responseMembersCard = requestSpecification.when().get(testController.getUrlMethod().getMembers(testController.idCard(responseCard, "Valores Endava")));
        Assert.assertThat("Error: The status code is not <200>", responseMembersCard.getStatusCode(), Matchers.equalTo(200));
        Assert.assertThat("There is not id member with the username silvanapareja1 in this card", testController.idMember(responseMembersCard, "silvanapareja1"), Matchers.not(""));
        System.out.println(responseMembersCard.getBody().asString());
    }


    @Given("^David wants to add a comment in the card Valores Endava$")
    public void davidWantsToAddACommentInTheCardValoresEndavaInTheListTODO() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }


    @When("^He sends the request to add a comment$")
    public void heSendsTheRequestToAddAComment() throws MalformedURLException {
        responseAddComment = requestSpecification.when().post(testController.postUrlMethod().postComment(testController.idCard(responseCard, "Valores Endava"), "Thougtful"));
        Assert.assertThat("Error: The status code is not <200>", responseAddComment.getStatusCode(), Matchers.equalTo(200));
    }

    @Then("^The Trello API adds the comment to the card Valores Endava$")
    public void theTrelloAPIAddsTheCommentToTheCardValoresEndava() throws MalformedURLException {
        responseCommentsCard = requestSpecification.when().get(testController.getUrlMethod().getComments(testController.idCard(responseCard, "Valores Endava")));
        Assert.assertThat("Error: The status code is not <200>", responseCommentsCard.getStatusCode(), Matchers.equalTo(200));
        System.out.println(responseCommentsCard.getBody().asString());
    }


    @Given("^David wants to move the card Valores Endava to the IN PROGRESS list$")
    public void davidWantsToMoveTheCardValoresEndavaToTheINPROGRESSList() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }


    @When("^He sends the petition for put the card in the IN PROGRESS list$")
    public void heSendsThePetitionForPutTheCardInTheINPROGRESSList() throws MalformedURLException {
        responseMoveCard = requestSpecification.when().put(testController.putUrlMethod().putCardInProgress(testController.idCard(responseCard, "Valores Endava"), testController.idLists(responseList, "IN PROGRESS")));
        Assert.assertThat("Error: The status code is not <200>", responseMoveCard.getStatusCode(), Matchers.equalTo(200));
    }


    @Then("^The Trello API moves the card to the IN PROGRESS list$")
    public void theTrelloAPIMovesTheCardToTheINPROGRESSList() {
    }


    @Given("^David wants to add a comment in a card that is on IN PROGRESS list$")
    public void davidWantsToAddACommentInACardThatIsOnINPROGRESSList() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @And("^has the In progress list id$")
    public void hasTheInProgressListId() throws MalformedURLException {
        responseList = requestSpecification.when().get(testController.getUrlMethod().getIdListUrl(testController.idBoard(response, "API Challenge 19")));
        Assert.assertThat("Error: The status code is not <200>", responseList.getStatusCode(), Matchers.equalTo(200));
    }

    @And("^has the card id in the IN PROGRESS list$")
    public void hasTheCardIdInTheINPROGRESSList() throws MalformedURLException {
        responseCard = requestSpecification.when().get(testController.getUrlMethod().getIdCard(testController.idLists(responseList, "IN PROGRESS")));
        Assert.assertThat("Error: The status code is not <200>", responseCard.getStatusCode(), Matchers.equalTo(200));
    }

    @When("^He sends the request to add the comment in the card$")
    public void heSendsTheRequestToAddTheCommentInTheCard() throws MalformedURLException {
        responseAddComment = requestSpecification.when().post(testController.postUrlMethod().postComment(testController.idCard(responseCard, "Valores Endava"), "Trusted"));
        Assert.assertThat("Error: The status code is not <200>", responseAddComment.getStatusCode(), Matchers.equalTo(200));
    }

    @Then("^The Trello API adds the comment to the card in this list$")
    public void theTrelloAPIAddsTheCommentToTheCardInThisList() {
    }


    @Given("^David wants to move the card Valores Endava to the DONE list$")
    public void davidWantsToMoveTheCardValoresEndavaToTheDONEList() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @And("^has the DONE list id$")
    public void hasTheDONEListId() throws MalformedURLException {
        responseList = requestSpecification.when().get(testController.getUrlMethod().getIdListUrl(testController.idBoard(response, "API Challenge 19")));
        Assert.assertThat("Error: The status code is not <200>", responseList.getStatusCode(), Matchers.equalTo(200));
    }

    @When("^He sends the petition for put the card in the DONE list$")
    public void heSendsThePetitionForPutTheCardInTheDONEList() throws MalformedURLException {
        responseCard = requestSpecification.when().get(testController.getUrlMethod().getIdCard(testController.idLists(responseList, "IN PROGRESS")));
        Assert.assertThat("Error: The status code is not <200>", responseCard.getStatusCode(), Matchers.equalTo(200));
        responseMoveCard = requestSpecification.when().put(testController.putUrlMethod().putCardInProgress(testController.idCard(responseCard, "Valores Endava"), testController.idLists(responseList, "DONE")));
        Assert.assertThat("Error: The status code is not <200>", responseMoveCard.getStatusCode(), Matchers.equalTo(200));
    }

    @Then("^The Trello API moves the card to the DONE list$")
    public void theTrelloAPIMovesTheCardToTheDONEList() {
    }

    @Given("^David wants to add a comment in a card that is on DONE list$")
    public void davidWantsToAddACommentInACardThatIsOnDONEList() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @And("^has the card id in the DONE list$")
    public void hasTheCardIdInTheDONEList() throws MalformedURLException {
        responseCard = requestSpecification.when().get(testController.getUrlMethod().getIdCard(testController.idLists(responseList, "DONE")));
        Assert.assertThat("Error: The status code is not <200>", responseCard.getStatusCode(), Matchers.equalTo(200));
    }

    @When("^He sends the request to add the comment in the card moved$")
    public void heSendsTheRequestToAddTheCommentInTheCardMoved() throws MalformedURLException {
        responseAddComment = requestSpecification.when().post(testController.postUrlMethod().postComment(testController.idCard(responseCard, "Valores Endava"), "Smart"));
        Assert.assertThat("Error: The status code is not <200>", responseAddComment.getStatusCode(), Matchers.equalTo(200));
    }

    @Given("^David wants to delete the card$")
    public void davidWantsToDeleteTheCard() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @When("^He sends the request to delete the card$")
    public void heSendsTheRequestToDeleteTheCard() throws MalformedURLException {
        responseCard = requestSpecification.when().get(testController.getUrlMethod().getIdCard(testController.idLists(responseList, "DONE")));
        Assert.assertThat("Error: The status code is not <200>", responseCard.getStatusCode(), Matchers.equalTo(200));
        responseMoveCard = requestSpecification.when().delete(testController.deleteUrlMethod().deleteCard(testController.idCard(responseCard, "Valores Endava")));
        Assert.assertThat("Error: The status code is not <200>", responseMoveCard.getStatusCode(), Matchers.equalTo(200));

    }

    @Then("^The Trello API deletes the card$")
    public void theTrelloAPIDeletesTheCard() {
    }

    @And("^has the new card id$")
    public void hasTheNewCardId() throws MalformedURLException {
        responseCard = requestSpecification.when().get(testController.getUrlMethod().getIdCard(testController.idLists(responseList, "IN PROGRESS")));
        Assert.assertThat("Error: The status code is not <200>", responseCard.getStatusCode(), Matchers.equalTo(200));
        Assert.assertThat("There is not id Card with the name Valores Endava", testController.idCard(responseCard, "Valores Endava"), Matchers.not(""));

    }

    @And("^has the new card id in the list$")
    public void hasTheNewCardIdInTheList() throws MalformedURLException {
        responseCard = requestSpecification.when().get(testController.getUrlMethod().getIdCard(testController.idLists(responseList, "DONE")));
        Assert.assertThat("Error: The status code is not <200>", responseCard.getStatusCode(), Matchers.equalTo(200));
        Assert.assertThat("There is not id Card with the name Valores Endava", testController.idCard(responseCard, "Valores Endava"), Matchers.not(""));
    }
}

