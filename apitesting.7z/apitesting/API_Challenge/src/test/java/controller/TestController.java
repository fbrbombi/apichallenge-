package controller;

import com.google.gson.Gson;
import io.restassured.response.Response;
import model.Board;
import model.Card;
import model.Lists;
import model.Member;
import net.thucydides.core.steps.ScenarioSteps;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

//import com.google.gson.JsonParser;
public class TestController extends ScenarioSteps {

    private HashMap<String, String> jsonInformation;
    private static final String KEY = "f53ee7aaffec1501cc39f6b2e65b0b5b";
    private static final String TOKEN = "27f8a703e024cdc55fdf9805a499a077c383f9d55c9bfac7af1f739c81d47a23";
    private static final String CONTENT_TYPE = "application/json";
    private static final String id = "5c48d85de5f8a01996d278ac";
    private String listToAddTheNewCard;
    private Board[] board;
    private Lists[] lists;
    private Card[] card;
    private Member[] member;
    public GetUrl getUrl;
    public PostUrl postUrl;
    public PutUrl putUrl;
    public DeleteUrl deleteUrl;

    public Map<String, String> getAuthParams() {
        Map<String, String> params = new HashMap<>();
        params.put("key", KEY);
        params.put("token", TOKEN);
        //params.put("content type", CONTENT_TYPE);
        return params;
    }

    public String idBoard(Response response, String boardName) {
        String boardId="";
        Gson gson = new Gson();

        board = gson.fromJson(response.getBody().asString(), Board[].class);

        for (int i = 0; i < board.length; i++) {
            if (board[i].getName().equals(boardName)) {
                boardId=board[i].getIdByName();
                System.out.println(board[i].getName());
                System.out.println(boardId);
            }

        }
        return boardId;
    }

    public String idLists(Response responseList, String nameList) {
        String ListId="";
        Gson gson = new Gson();

        lists = gson.fromJson(responseList.getBody().asString(), Lists[].class);

        for (int i = 0; i < lists.length; i++) {
            if (lists[i].getName().equals(nameList)) {
                ListId=lists[i].getId();
                System.out.println(lists[i].getName());
                System.out.println(ListId);
            }

        }
        return ListId;
    }

    public String idCard(Response responseCard,String cardName) throws MalformedURLException {
        String CardId="";
        Gson gson = new Gson();

        card = gson.fromJson(responseCard.getBody().asString(), Card[].class);

        for (int i = 0; i < card.length; i++) {
            if (card[i].getName().equals(cardName)) {
                CardId=card[i].getId();
                System.out.println(card[i].getName());
                System.out.println(CardId);
            }

        }
        return CardId;
    }

    public String idMember(Response responseMember,String username) {
        String MemberId="";
        Gson gson = new Gson();

        member = gson.fromJson(responseMember.getBody().asString(), Member[].class);

        for (int i = 0; i < member.length; i++) {
            if (member[i].getUsername().equals(username)) {
                MemberId=member[i].getId();
                System.out.println(member[i].getUsername());
                System.out.println(MemberId);
            }

        }
        return MemberId;
    }

    public  GetUrl getUrlMethod(){
        getUrl = new GetUrl();
        return getUrl;
    }

    public  PostUrl postUrlMethod(){
        postUrl = new PostUrl();
        return postUrl;
    }

    public  PutUrl putUrlMethod(){
        putUrl = new PutUrl();
        return putUrl;
    }

    public  DeleteUrl deleteUrlMethod(){
        deleteUrl = new DeleteUrl();
        return deleteUrl;
    }


}

