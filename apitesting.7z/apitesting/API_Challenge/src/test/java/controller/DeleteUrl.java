package controller;

import java.net.MalformedURLException;
import java.net.URL;

public class DeleteUrl {
    public URL deleteCard(String idCard) throws MalformedURLException {

        return new URL("https://api.trello.com/1/cards/"+idCard);
    }
}
