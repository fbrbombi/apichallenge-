package controller;

import java.net.MalformedURLException;
import java.net.URL;

public class PutUrl {
    public URL putCardInProgress(String idCard,String idList) throws MalformedURLException {

        return new URL("https://api.trello.com/1/cards/"+idCard+"?idList="+idList);
    }
}
