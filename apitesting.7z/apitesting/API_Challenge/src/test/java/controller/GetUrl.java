package controller;

import java.net.MalformedURLException;
import java.net.URL;

public class GetUrl {
    public URL getIdBoardUrl() throws MalformedURLException {

        return new URL("https://api.trello.com/1/members/me/boards?fields=name");
    }

    public URL getIdListUrl(String idBoard) throws MalformedURLException {

        return new URL("https://api.trello.com/1/boards/" + idBoard + "/lists");
    }

    public URL getIdCard(String idList1) throws MalformedURLException {

        return new URL("https://api.trello.com/1/lists/" + idList1 + "/cards?fields=name");
    }

    public URL getIdMember(String idBoard) throws MalformedURLException {

        return new URL("https://api.trello.com/1/boards/" + idBoard + "/members?fields=username");
    }

    public URL getMembers(String idCard) throws MalformedURLException {

        return new URL("https://api.trello.com/1/cards/" + idCard + "/members");
    }

    public URL getComments(String idCard) throws MalformedURLException {

        return new URL("https://api.trello.com/1/cards/" + idCard + "/actions");
    }
}
