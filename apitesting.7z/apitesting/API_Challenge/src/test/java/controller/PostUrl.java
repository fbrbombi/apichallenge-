package controller;

import java.net.MalformedURLException;
import java.net.URL;

public class PostUrl {


    public URL postCard(String idList,String cardname,String description) throws MalformedURLException {

        return new URL("https://api.trello.com/1/cards?name="+cardname+"&desc="+description+"&pos=top&due=2019-02-26&idList="+idList+"&keepFromSource=all");
    }


    public URL postMember(String idCard, String idMember) throws MalformedURLException {

        return new URL("https://api.trello.com/1/cards/" + idCard + "/idMembers?value="+idMember);
    }



    public URL postComment(String idCard,String comment) throws MalformedURLException {

        return new URL("https://api.trello.com/1/cards/" + idCard + "/actions/comments?text="+comment);
    }

}
