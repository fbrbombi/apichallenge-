package controllers;

public class Strings {
    public static final String BASE_URL = "https://api.trello.com/1/";
    public static final String BOARD = "https://api.trello.com/1/members/me/boards?fields=name&";
    public static final String LIST = "https://api.trello.com/1/boards/";
    public static final String LIST2 = "https://api.trello.com/1/boards/5c73efd58b07d4766c42f4d0/lists?fields=name";
    public static final String ADDCARD = "https://api.trello.com/1/cards/";
    public static final String GETCARD = "https://api.trello.com/1/lists/";
    public static final String GETMEMBERS = "https://api.trello.com/1/boards/";
    public static final String CARDUPDATE = "https://api.trello.com/1/cards/";
    public static final String MOVECARD = "https://api.trello.com/1/cards/";
    public static final String CREATELIST = "https://api.trello.com/1/lists/";

}
