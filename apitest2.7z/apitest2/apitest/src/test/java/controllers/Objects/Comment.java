package controllers.Objects;

public class Comment {
    private String id;

    public Comment(String id) {
        this.id = id;
    }

    public String getId(){
        return id;
    }
}
