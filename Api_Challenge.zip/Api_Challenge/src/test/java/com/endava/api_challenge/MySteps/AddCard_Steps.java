package com.endava.api_challenge.MySteps;

import com.endava.api_challenge.Controllers.TestController;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AddCard_Steps {
    private String id_List_TODO="";
    @Steps
    private TestController testController;
    private RequestSpecification requestSpecification;
    private Response response;
    private static final Logger logger = LoggerFactory.getLogger(GetListsBoard.class);

    @Given("^The user is on the board page in Trello$")
    public void theUserIsOnTheBoardPageInTrello() {
        requestSpecification  = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @When("^The user clicks on add another card button in the \"([^\"]*)\" list$")
    public void theUserClicksOnAddAnotherCardButtonInTheList(String arg0) throws Throwable {
        try {
            response = requestSpecification.when().get(testController.getListsInBoardUrl());
            id_List_TODO = testController.getIdList(response);
            String assert2 = id_List_TODO;
            logger.info("The id of the TODO list was correct, the id is "+ id_List_TODO);
            Assert.assertEquals("5c48df6f2217f65db47d41e3", assert2);
            Assert.assertEquals(200, response.getStatusCode());
        }catch (Throwable t){
            logger.error("The id of the TODO list was incorrect, the id is "+ id_List_TODO);
            Assert.fail();
        }
    }

    @And("^Feels all the fields$")
    public void feelsAllTheFields() {
    }

    @And("^Cliks on the Add Card button$")
    public void cliksOnTheAddCardButton() {
        try {
            response = requestSpecification.when().post(testController.postCardInListUrl(id_List_TODO));
            Assert.assertEquals(200, response.getStatusCode());
            logger.info("The card was added correctly to the TODO list");
        }catch (Throwable t){
            logger.error("The card wasn't created due to an error of the URL");
            Assert.fail();
        }
    }

    @Then("^The card is added to the TODO list$")
    public void theCardIsAddedToTheTODOList() {
        logger.info("The feature Adding a card was successful");
    }
}
