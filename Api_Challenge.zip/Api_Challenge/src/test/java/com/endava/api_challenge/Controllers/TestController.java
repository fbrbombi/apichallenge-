package com.endava.api_challenge.Controllers;

import com.jayway.jsonpath.JsonPath;
import io.restassured.response.Response;
import net.thucydides.core.steps.ScenarioSteps;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class TestController extends ScenarioSteps{
    private static final String Key = "34c940d1c336a03a5e7e06bcfc493dd8";
    private static final String Token = "4bf63ecdad9387a116daa045efb47686bc6b573469311063f8858f211199353d";
    private static final String Board = "5c48d85de5f8a01996d278ac";
    private static final String NAME = "Card by Santiago C";
    private static final String DESCRIPTION = "This is the card created by Santiago Cabrales for the API challenge";
    private static final String CARD_ID_NO_DELETE ="";

    public Map<String, String> getAuthParams(){
        Map<String,String> params = new HashMap<>();
        params.put("key",Key);
        params.put("token",Token);
        return params;
    }

    public URL getListsInBoardUrl() throws MalformedURLException {
        return new URL("https://api.trello.com/1/boards/"+ Board +"/lists");
    }

    public URL postCardInListUrl(String id_TODO_list) throws MalformedURLException {
        return  new URL("https://api.trello.com/1/cards?name="+NAME+"&desc="+DESCRIPTION+"&idList="+id_TODO_list+"&keepFromSource=all&key="+Key+"&token="+Token);
    }

    public URL postCommentaryInListUrl(String id_card, String comentario) throws MalformedURLException {
        return  new URL("https://api.trello.com/1/cards/"+id_card+"/actions/comments?text="+comentario+"&key="+Key+"&token="+Token);
    }

    public URL addNewMemberToCard(String id_Card, String id_Member) throws MalformedURLException {
        return  new URL("https://api.trello.com/1/cards/"+id_Card+"/idMembers?value="+id_Member+"&key="+Key);
    }

    public URL moveCardToNewList( String id_InProgress, String id_Card) throws MalformedURLException {
        return  new URL("https://api.trello.com/1/cards/"+id_Card+"/idList?value="+id_InProgress+"&key="+Key+"&token="+Token);
    }

    public URL deleteCard(String id_Card) throws MalformedURLException {
        return  new URL("https://api.trello.com/1/cards/"+id_Card+"?key="+Key+"&token="+Token);
        //return  new URL("https://api.trello.com/1/cards/"+CARD_ID_NO_DELETE+"?key="+Key+"&token="+Token);
    }

    public URL getCardsFromList(String id_TODO_list) throws MalformedURLException {
        return  new URL("https://api.trello.com/1/lists/"+id_TODO_list+"/cards?key="+Key+"&token="+Token);
    }

    public URL getMembersFromBoard() throws MalformedURLException {
        return  new URL("https://api.trello.com/1/boards/"+Board+"/members?key="+Key+"&token="+Token);
    }

    public String getIdList(Response response){
        String sJson = response.getBody().asString();
        String listId="";
        int length =  com.jayway.jsonpath.JsonPath.read(sJson,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = com.jayway.jsonpath.JsonPath.read(sJson, "$.["+i+"].name");
            if(name.equals("TODO")){
                listId = JsonPath.read(sJson, "$.["+i+"].id");
                return listId;
            }
        }
        return listId;
    }

    public String getIdListInProgress(Response response){
        String sJson = response.getBody().asString();
        String listId="";
        int length =  com.jayway.jsonpath.JsonPath.read(sJson,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = com.jayway.jsonpath.JsonPath.read(sJson, "$.["+i+"].name");
            if(name.equals("IN PROGRESS")){
                listId = JsonPath.read(sJson, "$.["+i+"].id");
                return listId;
            }
        }
        return listId;
    }

    public String getIdListDONE(Response response){
        String sJson = response.getBody().asString();
        String listId="";
        int length =  com.jayway.jsonpath.JsonPath.read(sJson,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = com.jayway.jsonpath.JsonPath.read(sJson, "$.["+i+"].name");
            if(name.equals("DONE")){
                listId = JsonPath.read(sJson, "$.["+i+"].id");
                return listId;
            }
        }
        return listId;
    }

    public String getCardId(Response response){
        String sJson = response.getBody().asString();
        String cardId="";
        int length =  com.jayway.jsonpath.JsonPath.read(sJson,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = com.jayway.jsonpath.JsonPath.read(sJson, "$.["+i+"].name");
            if(name.equals("Card by Santiago C")){
                cardId = JsonPath.read(sJson, "$.["+i+"].id");
                return cardId;
            }
        }
        return cardId;
    }

    public String getMemberId(Response response){
        String sJson = response.getBody().asString();
        String memberId="";
        int length =  com.jayway.jsonpath.JsonPath.read(sJson,"$.length()");
        for (int i=0; i< length; i++ ){
            String username = com.jayway.jsonpath.JsonPath.read(sJson, "$.["+i+"].username");
            if(username.equals("dayanafigueredo1")){
                memberId = JsonPath.read(sJson, "$.["+i+"].id");
                return memberId;
            }
        }
        return memberId;
    }
}
