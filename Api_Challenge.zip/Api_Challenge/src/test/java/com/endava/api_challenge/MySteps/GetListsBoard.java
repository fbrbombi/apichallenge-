package com.endava.api_challenge.MySteps;

import com.endava.api_challenge.Controllers.TestController;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GetListsBoard {
    @Steps
    private TestController testController;
    private RequestSpecification requestSpecification;
    private Response response;
    private static final Logger logger = LoggerFactory.getLogger(GetListsBoard.class);



    @Given("^He is on the board page$")
    public void heIsOnTheBoardPage() {
        requestSpecification  = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @When("^He clicks on the \"([^\"]*)\"$")
    public void heClicksOnThe(String arg0){

        try {
            response = requestSpecification.when().get(testController.getListsInBoardUrl());
            logger.info("The list of the board was found successfully");
            Assert.assertEquals(200, response.getStatusCode());
        }catch (Throwable t){
            logger.error("Error getting the lists of the board ");
            Assert.fail();
        }

    }

    @Then("^The lists of the board are displayed$")
    public void theListsOfTheBoardAreDisplayed() {
        logger.info("The info of the lists was consulted.");
    }



}
