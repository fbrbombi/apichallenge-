package com.endava.api_challenge.MySteps;

import com.endava.api_challenge.Controllers.TestController;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MoveCard_Steps {
    private String id_List_TODO="";
    private String id_List_InProgress="";
    private String id_List_DONE="";
    private String id_Card="";
    private String commentary_INPROGRESS="The card is in the IN PROGRESS list";
    private String commentary_DONE="The card is in the DONE list";

    @Steps
    private TestController testController;
    private RequestSpecification requestSpecification;
    private Response response;
    private Response response2;
    private Response response3;
    private static final Logger logger = LoggerFactory.getLogger(GetListsBoard.class);

    @Given("^The user is on the board page in Trello app$")
    public void theUserIsOnTheBoardPageInTrelloApp() {
        requestSpecification  = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @When("^The user drags the card to a new list$")
    public void theUserDragsTheCardToANewList(){

        try {
            response = requestSpecification.when().get(testController.getListsInBoardUrl());
            id_List_InProgress = testController.getIdListInProgress(response);
            String assert2 = id_List_InProgress;
            logger.info("The id of the IN PROGRESS list was correct, the id is "+ id_List_InProgress);
            Assert.assertEquals("5c759df32a97877c31e386d9", assert2);
            Assert.assertEquals(200, response.getStatusCode());

            id_List_TODO = testController.getIdList(response);
            response2 = requestSpecification.when().get(testController.getCardsFromList(id_List_TODO));
            String assert3 = id_List_TODO;
            logger.info("The id of the TODO list was correct, the id is "+ id_List_TODO);
            Assert.assertEquals("5c48df6f2217f65db47d41e3", assert3);
            Assert.assertEquals(200, response2.getStatusCode());

            id_Card = testController.getCardId(response2);
            logger.info("The id of the card was found correctly");
            Assert.assertEquals(200, response2.getStatusCode());
            response3= requestSpecification.when().put(testController.moveCardToNewList(id_List_InProgress, id_Card));
            Assert.assertEquals(200, response3.getStatusCode());

        }catch (Throwable t){
            logger.error("The id of the TODO list could be incorrect, the id is "+ id_List_TODO);
            logger.error("The id of the TODO list could be incorrect, the id is "+ id_List_InProgress);
            logger.error("Maybe the id of the card wasn't found "+ id_Card);
            Assert.fail();
        }
    }

    @Then("^The card is added to a new list$")
    public void theCardIsAddedToANewList() {
        logger.info("The feature Move a card to the In Progress list was successful");
    }


    @Given("^The user is on the board page of trello$")
    public void theUserIsOnTheBoardPageOfTrello() {
        requestSpecification  = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @When("^The user clicks the card moved$")
    public void theUserClicksTheCardMoved(){

        try {
            response = requestSpecification.when().get(testController.getListsInBoardUrl());
            id_List_InProgress = testController.getIdListInProgress(response);
            String assert2 = id_List_InProgress;
            logger.info("The id of the IN PROGRESS list was correct, the id is "+ id_List_InProgress);
            Assert.assertEquals("5c759df32a97877c31e386d9", assert2);
            Assert.assertEquals(200, response.getStatusCode());

            response2 = requestSpecification.when().get(testController.getCardsFromList(id_List_InProgress));
            id_Card = testController.getCardId(response2);
            logger.info("The id of the card was found correctly");
            Assert.assertEquals(200, response2.getStatusCode());
        }catch (Throwable t){
            logger.error("The id of the In Progress list could be incorrect, the id is "+ id_List_InProgress);
            logger.error("Maybe the id of the card wasn't found "+ id_Card);
            Assert.fail();
        }
    }

    @And("^The user writes the comment in progress list$")
    public void theUserWritesTheCommentInProgressList() {
    }

    @And("^The user clicks on the Save button after the comment$")
    public void theUserClicksOnTheSaveButtonAfterTheComment(){

        try {
            response = requestSpecification.when().post(testController.postCommentaryInListUrl(id_Card, commentary_INPROGRESS));
            logger.info("The commentary was added correctly to the card");
            Assert.assertEquals(200, response.getStatusCode());

        }catch (Throwable t){
            logger.error("The post of the  commentary failed due to an error in the URL");
            Assert.fail();
        }
    }


    @Then("^The commentary is added to the card in the in progress$")
    public void theCommentaryIsAddedToTheCardInTheInProgress() {
        logger.info("The feature Adding a commentary to the card was successful");
    }

    @When("^The user drags the card to the DONE list$")
    public void theUserDragsTheCardToTheDONEList() {
        try {
            response = requestSpecification.when().get(testController.getListsInBoardUrl());
            id_List_InProgress = testController.getIdListInProgress(response);
            String assert2 = id_List_InProgress;
            logger.info("The id of the IN PROGRESS list was correct, the id is "+ id_List_InProgress);
            Assert.assertEquals("5c759df32a97877c31e386d9", assert2);
            Assert.assertEquals(200, response.getStatusCode());
            id_List_DONE = testController.getIdListDONE(response);
            response2 = requestSpecification.when().get(testController.getCardsFromList(id_List_InProgress));
            String assert3 = id_List_DONE;
            logger.info("The id of the DONE list was correct, the id is "+ id_List_DONE);
            Assert.assertEquals("5c769a72d2dc292cd6554c3a", assert3);
            Assert.assertEquals(200, response2.getStatusCode());

            id_Card = testController.getCardId(response2);
            logger.info("The id of the card was found correctly");
            Assert.assertEquals(200, response2.getStatusCode());
            response3= requestSpecification.when().put(testController.moveCardToNewList(id_List_DONE, id_Card));
            logger.info("The card was moved successfully");
            Assert.assertEquals(200, response3.getStatusCode());


        }catch (Throwable t){
            logger.error("The id of the TODO list could be incorrect, the id is "+ id_List_TODO);
            logger.error("The id of the TODO list could be incorrect, the id is "+ id_List_InProgress);
            logger.error("Maybe the id of the card wasn't found "+ id_Card);
            Assert.fail();
        }
    }

    @Then("^The card is added to the DONE list$")
    public void theCardIsAddedToTheDONEList() {
        logger.info("The feature Move a card to the DONE list was successful");
    }



    @Given("^The user is on the board page of trello after moving the card$")
    public void theUserIsOnTheBoardPageOfTrelloAfterMovingTheCard() {
        requestSpecification  = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @When("^The user clicks the card moved to the done list$")
    public void theUserClicksTheCardMovedToTheDoneList() {
        try{
            response = requestSpecification.when().get(testController.getListsInBoardUrl());
            id_List_DONE = testController.getIdListDONE(response);
            String assert2 = id_List_DONE;
            logger.info("The id of the DONE list was correct, the id is "+ id_List_DONE);
            Assert.assertEquals("5c769a72d2dc292cd6554c3a", assert2);
            Assert.assertEquals(200, response.getStatusCode());

            response2 = requestSpecification.when().get(testController.getCardsFromList(id_List_DONE));
            id_Card = testController.getCardId(response2);
            logger.info("The id of the card was found correctly");
            Assert.assertEquals(200, response2.getStatusCode());
        }catch (Throwable t){
            logger.error("The id of the In Progress list could be incorrect, the id is "+ id_List_DONE);
            logger.error("Maybe the id of the card wasn't found "+ id_Card);
            Assert.fail();
        }
    }

    @And("^The user writes the comment done list$")
    public void theUserWritesTheCommentDoneList() {
    }

    @And("^The user clicks on the Save button in the DONE LIST$")
    public void theUserClicksOnTheSaveButtonInTheDONELIST() {
        try {
            response = requestSpecification.when().post(testController.postCommentaryInListUrl(id_Card, commentary_DONE));
            logger.info("The commentary was added correctly to the card");
            Assert.assertEquals(200, response.getStatusCode());

        }catch (Throwable t){
            logger.error("The post of the  commentary failed due to an error in the URL");
            Assert.fail();
        }

    }

    @Then("^The commentary is added to the card in the in DONE list$")
    public void theCommentaryIsAddedToTheCardInTheInDONEList() {
        logger.info("The feature Adding a commentary to the card was successful");
    }

}
