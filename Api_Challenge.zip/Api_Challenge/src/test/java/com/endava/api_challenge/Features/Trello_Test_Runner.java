package com.endava.api_challenge.Features;


import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = {"src/test/Resources/Features" }, glue = "com.endava.api_challenge/MySteps")

public class Trello_Test_Runner {


}
