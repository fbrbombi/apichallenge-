package com.endava.api_challenge.MySteps;

import com.endava.api_challenge.Controllers.TestController;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DeleteCard_Steps {

    private String id_List_DONE="";
    private String id_Card="";

    @Steps
    private TestController testController;
    private RequestSpecification requestSpecification;
    private Response response;
    private Response response2;
    private static final Logger logger = LoggerFactory.getLogger(GetListsBoard.class);

    @Given("^The user is on the board page in Trello web page$")
    public void theUserIsOnTheBoardPageInTrelloWebPage() {
        requestSpecification  = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @When("^The user selects the card to delete$")
    public void theUserSelectsTheCardToDelete(){
        try {
            response = requestSpecification.when().get(testController.getListsInBoardUrl());
            id_List_DONE = testController.getIdListDONE(response);
            String assert2 = id_List_DONE;
            logger.info("The id of the DONE list was correct, the id is "+ id_List_DONE);
            Assert.assertEquals("5c769a72d2dc292cd6554c3a", assert2);
            Assert.assertEquals(200, response.getStatusCode());

            response2 = requestSpecification.when().get(testController.getCardsFromList(id_List_DONE));
            id_Card = testController.getCardId(response2);
            logger.info("The id of the card was found correctly");
            Assert.assertEquals(200, response2.getStatusCode());
        }catch (Throwable t){
            logger.error("The id of the In Progress list could be incorrect, the id is "+ id_List_DONE);
            logger.error("Maybe the id of the card wasn't found "+ id_Card);
            Assert.fail();
        }
    }

    @And("^The user clicks on the archive button$")
    public void theUserClicksOnTheArchiveButton() {
    }

    @And("^the user clicks on the delete button$")
    public void theUserClicksOnTheDeleteButton(){
        try {
            response= requestSpecification.when().delete(testController.deleteCard(id_Card));
            logger.info("The card was  deleted successfully");
            Assert.assertEquals(200, response.getStatusCode());

        }catch (Throwable t){
            logger.error("The card wasn't deleted due to an error in the URL");
            Assert.fail();
        }
    }

    @Then("^The card is deleted$")
    public void theCardIsDeleted() {
         logger.info("The feature Delete a card was successful");
    }
}
