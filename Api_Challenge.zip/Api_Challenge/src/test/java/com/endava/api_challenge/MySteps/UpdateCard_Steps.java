package com.endava.api_challenge.MySteps;

import com.endava.api_challenge.Controllers.TestController;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UpdateCard_Steps {
    private String id_List_TODO="";
    private String id_Card="";
    private String id_Member="";

    @Steps
    private TestController testController;
    private RequestSpecification requestSpecification;
    private Response response;
    private Response response2;
    private Response response3;
    private String Commentary="The card is in the TODO list";
    private static final Logger logger = LoggerFactory.getLogger(GetListsBoard.class);

    @Given("^The user is on the board page$")
    public void theUserIsOnTheBoardPage() {
        requestSpecification  = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @When("^The user clicks the created card$")
    public void theUserClicksTheCreatedCard(){
        try {
            response = requestSpecification.when().get(testController.getListsInBoardUrl());
            id_List_TODO = testController.getIdList(response);
            String assert2 = id_List_TODO;
            logger.info("The id of the TODO list was correct, the id is "+ id_List_TODO);
            Assert.assertEquals("5c48df6f2217f65db47d41e3", assert2);
            Assert.assertEquals(200, response.getStatusCode());

            response2 = requestSpecification.when().get(testController.getCardsFromList(id_List_TODO));
            id_Card = testController.getCardId(response2);
            logger.info("The id of the card was found correctly");
            Assert.assertEquals(200, response2.getStatusCode());

        }catch (Throwable t){
            logger.error("The id of the TODO list could be incorrect, the id is "+ id_List_TODO);
            logger.error("Maybe the id of the card wasn't found "+ id_Card);
            Assert.fail();
        }
    }

    @And("^The user writes the comment$")
    public void theUserWritesTheComment() {
    }

    @And("^The user clicks on the Save button$")
    public void theUserClicksOnTheSaveButton(){
        try {
            response = requestSpecification.when().post(testController.postCommentaryInListUrl(id_Card,Commentary));
            Assert.assertEquals(200, response.getStatusCode());
            logger.info("The commentary was added correctly to the card");
        }catch (Throwable t){
            logger.error("The post of the  commentary failed due to an error in the URL");
            Assert.fail();
        }

    }

    @Then("^The commentary is added to the card$")
    public void theCommentaryIsAddedToTheCard() {
        logger.info("The feature Adding a commentary to the card was successful");
    }

    @And("^The user clicks on the Add Member button$")
    public void theUserClicksOnTheAddMemberButton(){
        try {
            response3  = requestSpecification.when().get(testController.getMembersFromBoard());
            id_Member = testController.getMemberId(response3);
            logger.info("The id of the member of the board was found successfully: "+ id_Member);
            Assert.assertEquals(200, response.getStatusCode());
        }catch (Throwable t){
            logger.error("The id of the member is incorrect or wasn't found "+ id_List_TODO);
            Assert.fail();
        }
    }

    @And("^The user selects the new member$")
    public void theUserSelectsTheNewMember(){

        try {
            response = requestSpecification.when().post(testController.addNewMemberToCard(id_Card, id_Member));
            logger.info("The member was added successfully to the card in the TODO");
            Assert.assertEquals(200, response.getStatusCode());
        }catch (Throwable t){
            logger.error("Adding a member to the card failed due to a problem in the URL");
            Assert.fail();
        }
    }

    @Then("^The new member is added to the selected card$")
    public void theNewMemberIsAddedToTheSelectedCard() {
        logger.info("The feature Adding a member to the card was successful");
    }
}
