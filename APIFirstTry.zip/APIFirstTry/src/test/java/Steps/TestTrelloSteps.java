package Steps;
import Controllers.Lists;
import Controllers.TestController;
import com.google.gson.Gson;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.jruby.RubyProcess;
import org.junit.Assert;

import java.net.MalformedURLException;

public class TestTrelloSteps {
    @Steps
    private TestController testController;

    private RequestSpecification requestSpecification;

    private Response response;
    Gson gson = new Gson();
    Lists[] lists;
    private Lists lista;

    private static String idCard;
    private String idList;



    //GET BOARD LISTS //////////////////////////////////////
    @Given("^The user wants to know the list of the board \"([^\"]*)\"$")
    public void theUserWantsToKnowTheListOfTheBoard(String arg0) throws Throwable {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());

    }

    @When("^the users sends the petition$")
    public void theUsersSendsThePetition() throws MalformedURLException {
        response = requestSpecification.when().get(testController.getListsInBoardUrl());
    }

    @Then("^displays the list of boards$")
    public String displaysTheListOfBoards() throws MalformedURLException {
       // System.out.println(response.getBody().asString());
        lists = gson.fromJson(response.body().asString(), Lists[].class);

        for (int i = 0; i < (lists.length); i++) {
          //  System.out.println(lists[i].getName());
          //  System.out.println(lists[i].getId());
           if (lists[i].getName().equals("TODO")) {
               System.out.println(lists[i].getName());
               System.out.println(lists[i].getId());
               idList = lists[i].getId();
               break;
           }


        }

        return "Id not found";

    }



    // CREATE A CARD ////////////////////////////////////////
    @Given("^The user wants to create a card Challenge$")
    public void theUserWantsToCreateACardChallenge() {
       requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getCardParams());
    }

    @When("^the user sends the petition$")
    public void theUserSendsThePetition() throws MalformedURLException {
       response = requestSpecification.when().post(testController.postCardInBoardUrl());
       // testController.setidCard();
    }

    @Then("^create a card on the TODO list$")
    public void createACardOnTheTODOList() {
        System.out.println(response.getBody().asString());
        String sJson = response.getBody().asString();
        JsonPath archivo =response.jsonPath();
        System.out.println(archivo.get("id").toString());
         idCard = archivo.get("id").toString();
        testController.setidCard(idCard);

    }



    //GET THE MEMBERS ID
    @Given("^The user wants to know the members id$")
    public void theUserWantsToKnowTheMembersId() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getMembersParams());

    }

    @When("^the user request the members id$")
    public void theUserRequestTheMembersId() throws MalformedURLException {
        response = requestSpecification.when().get(testController.getidMembersUrl());
    }

    @Then("^displays the members id$")
    public void displaysTheMembersId() {
        System.out.println(response.getBody().asString());
    }


    //ADD MEMBERS TO THE CARD//////////////////////////////////////////
    @Given("^The user wants to add members to the card \"([^\"]*)\"$")
    public void theUserWantsToAddMembersToTheCard(String arg0) throws Throwable {
            requestSpecification = RestAssured.given().contentType("application/json")
                    .and().queryParams(testController.getMembersParams());
    }

    @When("^the user sends the members petition$")
    public void theUserSendsTheMembersPetition() throws MalformedURLException {
             response = requestSpecification.when().post(testController.postCardMemebersUrl(idCard));
    }


    @Then("^add members to the \"([^\"]*)\" card$")
    public void addMembersToTheCard(String arg0) throws Throwable {
        System.out.println(response.getBody().asString());
    }


    //COMMENT CARD////////////////////////////////////////////////////
    @Given("^The user wants to add a comment to the card Prueba$")
    public void theUserWantsToAddACommentToTheCardPrueba() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getMembersParams());
    }

    @When("^the user sends the comment petition$")
    public void theUserSendsTheCommentPetition() throws MalformedURLException {
        response = requestSpecification.when().post(testController.postCommentUrl(idCard));
    }

    @Then("^add members to the Prueba Card$")
    public void addMembersToThePruebaCard() {
        System.out.println(response.getBody().asString());
    }


    //MOVE THE CARD TO IN PROGRESS///////////////////////////////////////////////////
    @Given("^the user wants to move the card$")
    public void theUserWantsToMoveTheCard() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getMoveParams());
    }

    @When("^the user sends the move petition$")
    public void theUserSendsTheMovePetition() throws MalformedURLException {
        response = requestSpecification.when().put(testController.moveCardUrl(idCard));
    }

    @Then("^move the card to the IN PROGRESS list$")
    public void moveTheCardToTheINPROGRESSList() {
        System.out.println(response.getBody().asString());
    }


    //ADD A COMMENT TO THE IN PROGRESS LIST///////////////////////////
    @Given("^The user wants to add a comment to the Prueba (\\d+) card$")
    public void theUserWantsToAddACommentToThePruebaCard(int arg0) {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.secondComment());
    }

    @When("^the user sends the comment petition (\\d+)$")
    public void theUserSendsTheCommentPetition(int arg0) throws MalformedURLException {
        response = requestSpecification.when().post(testController.postCommentUrl(idCard));
    }

    @Then("^comments the Prueba (\\d+) Card$")
    public void commentsThePruebaCard(int arg0) {
        System.out.println(response.getBody().asString());
    }

    //MOVE TO DONE LIST//////////////////////////////////////////////////////
    @Given("^the user wants to move the Prueba card$")
    public void theUserWantsToMoveThePruebaCard() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getDoneParams());
    }

    @When("^the user sends the moving petition$")
    public void theUserSendsTheMovingPetition() throws MalformedURLException {
        response = requestSpecification.when().put(testController.moveCardUrl(idCard));
    }

    @Then("^moves the card to the DONE list$")
    public void movesTheCardToTheDONEList() {
        System.out.println(response.getBody().asString());
    }

    //COMMENT DONE CARD ///////////////////////////////////////////////
    @Given("^the user wants to add a comment to the card$")
    public void theUserWantsToAddACommentToTheCard() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.secondComment());
    }

    @When("^the user sends the move DONE petition$")
    public void theUserSendsTheMoveDONEPetition() throws MalformedURLException {
        response = requestSpecification.when().post(testController.postCommentUrl(idCard));
    }

    @Then("^comments the Prueba Card$")
    public void commentsThePruebaCard() {
        System.out.println(response.getBody().asString());
    }


    // GET THE MEMBERS /////////////////////////////////////
    @Given("^the user wants to get the members$")
    public void theUserWantsToGetTheMembers() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getMoveParams());

    }


    @When("^the user sends a petition$")
    public void theUserSendsAPetition() throws MalformedURLException {
        response = requestSpecification.when().get(testController.getMemeberCard(idCard));
    }

    @Then("^he gets the members of the card$")
    public void heGetsTheMembersOfTheCard() {
        System.out.println(response.getBody().asString());
    }



    //DELETE THE CARD //////////////////////////////////////
    @Given("^the user wants to delete the card$")
    public void theUserWantsToDeleteTheCard() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(testController.secondComment());
    }

    @When("^the user sends a delete petition$")
    public void theUserSendsADeletePetition() throws MalformedURLException {
        response = requestSpecification.when().delete(testController.getMemeberCard(idCard));
    }

    @Then("^he deletes the card$")
    public void heDeletesTheCard() {
        System.out.println(response.getBody().asString());
    }


    @And("^the server responds with success OK$")
    public void theServerRespondsWithSuccessOK() {
        Assert.assertEquals(200, response.getStatusCode());
    }
}
