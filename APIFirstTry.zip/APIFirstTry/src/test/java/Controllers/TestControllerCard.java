package Controllers;

import java.util.Random;

public class TestControllerCard {
    private String cardName;
    private String description;
    private String comments;
    private String CARDID;

    public void setCARDID(String CARDID) {
        this.CARDID = CARDID;
    }

    public String getCARDID() {
        return CARDID;
    }

    public String getComments() {
        return comments;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getCardName() {
        return cardName;
    }

    public String getDescription() {
        return description;
    }


    public TestControllerCard(String cardName, String description) {
        this.cardName = cardName;
        this.description = description;
    }

    public TestControllerCard(String description) {
        this.description = description;
    }

}
