package Controllers;

import com.google.gson.Gson;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.net.MalformedURLException;

public class GetLists {
    Gson gson = new Gson();
    Lists[] lists;
    private static String idList;
    RequestSpecification requestSpecification;
    TestController testController;
    Response response;
    Object jsonObject;
    Lists name = new Lists("TODO", "");
    TestControllerCard desc = new TestControllerCard("This is the first comment on the TO DO list");

    public String GetLists() throws MalformedURLException {
        lists = gson.fromJson(response.body().asString(), Lists[].class);

        for (int i = 0; i < (lists.length); i++) {
            //  System.out.println(lists[i].getName());
            //  System.out.println(lists[i].getId());
            if (lists[i].getName().equals("TODO")) {
                System.out.println(lists[i].getName());
                System.out.println(lists[i].getId());
                return lists[i].getId();

            }
        }

        return "Id not found";


    }
}
