package Controllers;

public class Members {
    private String memberName;
    private String memberID;

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    public Members(String memberName, String memberID) {
        this.memberName = memberName;
        this.memberID = memberID;
    }

    public String getMemberName() {
        return memberName;
    }

    public String getMemberID() {
        return memberID;
    }
}
