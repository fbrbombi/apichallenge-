package Controllers;

import Features.TrelloTestRunner;
import net.thucydides.core.annotations.Steps;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import java.util.ArrayList;
import java.util.List;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class TestController {
    @Steps
    private static final String KEY = "3e7f824766ed50b79e4ec452693518b6";
    private static final String TOKEN = "7ec94034f53ed71a12a56ca0bfd71afc5f3ec5ba697f3d04c04edfd96f1e893c";
    private static final String CONTENT_TYPE = "";
    private static final String idBOARD = "5c48d85de5f8a01996d278ac";
    private static final String idTODO = "5c48df6f2217f65db47d41e3";
    private static final String idINPROGRES = "5c759df32a97877c31e386d9";
    private static final String idDONE = "5c48df8007624036c8f61ba6";
    private String idCard;
    private String idList;
    Lists lists = new Lists();
    TestControllerCard card = new TestControllerCard("Pabellon", "ThirdCard Try");
    Members member = new Members("cmarquez", "5c700c69ad6f486df2fa561b");
    TestControllerCard desc = new TestControllerCard("This is the first comment on the TO DO list");
    TestControllerCard move = new TestControllerCard("This is the second pinche IN PROGRESS");

    public void setidCard(String id){
        idCard=id;
    }

    public void setIdList(String idL) {
        idList = idL;
    }

    private String listToAddTheNewCard;
    private String name;

    public Map<String, String> getAuthParams() {
        Map<String, String> params = new HashMap<>();
        params.put("key", KEY);
        params.put("token", TOKEN);
        params.put("name",lists.getName());
        params.put("id",lists.getId());
        return params;
    }

    public URL getListsInBoardUrl() throws MalformedURLException {
        return new URL("https://api.trello.com/1/boards/" + idBOARD + "/lists");
    }

   // Map<String, String> params2 = new HashMap<>();

    public Map<String, String> getCardParams() {
        Map<String, String> params = new HashMap<>();
        params.put("key", KEY);
        params.put("token", TOKEN);
        params.put("idList", idTODO);
        params.put("name", card.getCardName());
        params.put("desc", card.getDescription());

        return params;

    }
   /* public void setParams2(String key, String data){
        params2.put(key, data);
    }*/

    public URL postCardInBoardUrl() throws MalformedURLException {
        return new URL("https://api.trello.com/1/cards/");
    }


    public URL getidMembersUrl() throws MalformedURLException {
        return new URL("https://api.trello.com/1/boards/" + idBOARD + "/members");
    }

    public URL getMemeberCard(String idCard) throws MalformedURLException {
        return new URL("https://api.trello.com/1/cards/" + idCard );
    }

    public Map<String, String> getMembersParams() {
        Map<String, String> params = new HashMap<>();
        params.put("key", KEY);
        params.put("token", TOKEN);
        params.put("value", member.getMemberID());
        params.put("text", desc.getDescription());
        return params;

    }

    public URL postCardMemebersUrl(String idCard) throws MalformedURLException {
        return new URL("https://api.trello.com/1/cards/" + idCard + "/idMembers");
    }

    public URL postCommentUrl(String idCard) throws MalformedURLException {
        return new URL("https://api.trello.com/1/cards/" + idCard + "/actions/comments");
    }

    public Map<String, String> getMoveParams() {
        Map<String, String> params = new HashMap<>();
        params.put("key", KEY);
        params.put("token", TOKEN);
        params.put("idList", idINPROGRES);
        params.put("id", idCard);
        params.put("name", card.getCardName());
        params.put("desc", card.getDescription());
        return params;

    }

    public URL moveCardUrl(String idCard) throws MalformedURLException {
        return new URL("https://api.trello.com/1/cards/" + idCard);
    }

    public Map<String, String> secondComment() {
        Map<String, String> params = new HashMap<>();
        params.put("key", KEY);
        params.put("token", TOKEN);
        params.put("idList", idINPROGRES);
        params.put("id", idCard);
        params.put("text", move.getDescription());
        return params;

    }

    public Map<String, String> getDoneParams() {
        Map<String, String> params = new HashMap<>();
        params.put("key", KEY);
        params.put("token", TOKEN);
        params.put("idList", idDONE);
        params.put("id", idCard);
        params.put("name", card.getCardName());
        params.put("desc", card.getDescription());
        return params;

    }
}

