package steps;

;
import com.google.gson.Gson;
import controllers.TestController;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Step;
import org.junit.Assert;
import utils.DataSession;
import utils.Members;

import java.net.MalformedURLException;

import static utils.RandomVaraibles.getRandomString;

public class MyStepdefs {

    private RequestSpecification requestSpecification;
    private Response response;
    Members[] members;
    private Gson gson = new Gson();

    @Step
    public String description(String html) {
        return html;
    }


    @Given("^The user wants to know the list that he has is a board$")
    public void theUserWantsToKnowTheListThatHeHasIsABoard() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(TestController.getAuthParams());
    }

    @When("^the user sends the petition for get the lists of his board$")
    public void theUserSendsThePetitionForGetTheListsOfHisBoard() throws MalformedURLException {
        response = requestSpecification.when().get(TestController.getlistsInBoards());
    }

    @Then("^the trello api should response only with the list of specific board$")
    public void theTrelloApiShouldResponseOnlyWithTheListOfSpecificBoard() {
      //  System.out.println("respuesta test trello");
        // System.out.println(response.getBody().asString());
    }


    @Given("^the user has the information of token and API KEY$")
    public void theUserHasTheInformationOfTokenAndAPIKEY() {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(TestController.getAuthParams());

        requestSpecification.baseUri(TestController.getBaseUrl());
    }

    @Given("^the user knows the ID list of TO DO$")
    public void theUserKnowsTheIDListOfTODO() {

    }

    @When("^the user send request to create the card$")
    public void theUserSendRequestToCreateTheCard() throws MalformedURLException {
        String name = getRandomString(15);
        String description = getRandomString(30);

        DataSession.setInSession(DataSession.Data.NAME, name);
        DataSession.setInSession(DataSession.Data.DESCRIPTION, description);
        response = requestSpecification.when().post(TestController.postCreateCard());
    }

    @Then("^the service respond with a success code$")
    public void theServiceRespondWithASuccessCode() {
        // System.out.println("respuesta en add "+ response.getBody().asString());
        Assert.assertEquals(200, response.getStatusCode());

    }

    @And("^the response contain an ID correspond with the card$")
    public void theResponseContainAnIDCorrespondWithTheCard() {

        JsonPath jsonResponse = response.jsonPath();
        String id = jsonResponse.get("id").toString();

        Assert.assertNotNull(id);
        DataSession.setInSession(DataSession.Data.IDCARD, id);
    }

    @And("^the card is created in the list TO DO$")
    public void theCardIsCreatedInTheListTODO() {
     //   System.out.println("response create" + response.getBody().asString());
        String name = response.jsonPath().get("name");
        Assert.assertEquals(name, DataSession.getFromSession(DataSession.Data.NAME));
        description("the card called " + name + " was successfully created :) ");

    }

    @Given("^the user has already created a card$")
    public void theUserHasAlreadyCreatedACard() throws MalformedURLException {
        theUserSendRequestToCreateTheCard();
    }

    @When("^the user add a member in the card$")
    public void theUserAddAMemberInTheCard() throws MalformedURLException {
        String id = getterMembers((int) (Math.random() * 10) + 1);
        DataSession.setInSession(DataSession.Data.IDMember, id);
        response = requestSpecification.when().post(TestController.postAddMembers(id));
    }


    @And("^the member has been added to the card$")
    public void theMemberHasBeenAddedToTheCard() {

    }

    @When("^the user adds a coment in the card$")

    public void theUserAddsAComentInTheCard() throws MalformedURLException {
        DataSession.setInSession(DataSession.Data.COMMENT, "este es el comentario 222222xd");
        response = requestSpecification.when().post(TestController.postAddComent());
    }

    @And("^the coment has been added to the card$")
    public void theComentHasBeenAddedToTheCard() {


    }

    @And("^the user knows the ID list of IN PROGRESS$")
    public void theUserKnowsTheIDListOfINPROGRESS() {

      //  System.out.println(DataSession.getFromSession(DataSession.Data.IDCARD) + "");

    }

    @When("^the card is moved to list from TO DO to IN PROGRESS$")
    public void theCardIsMovedToListFromTODOToINPROGRESS() throws MalformedURLException, InterruptedException {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(TestController.getAuthParams());

        requestSpecification.baseUri(TestController.getBaseUrl());
        response = requestSpecification.when().put(TestController.putMoveCardProgress());
        // System.out.println("\nrespuesta en el when  " + response.getBody().asString());

        response.then().log().all().extract();

    }

    @And("^the card has been moved of list$")
    public void theCardHasBeenMovedOfList() throws MalformedURLException {


    }

    @When("^the card is moved to list from IN PROGRESS to DONE$")
    public void theCardIsMovedToListFromINPROGRESSToDONE() throws MalformedURLException {
        requestSpecification = RestAssured.given().contentType("application/json")
                .and().queryParams(TestController.getAuthParams());

        requestSpecification.baseUri(TestController.getBaseUrl());
        response = requestSpecification.when().put(TestController.putMoveCardDone());
    }

    @When("^the user delete the card$")
    public void theUserDeleteTheCard() throws MalformedURLException {
        response = requestSpecification.when().delete(TestController.deleteCard());
    }

    @And("^the card has been delete$")
    public void theCardHasBeenDelete() {
     //   System.out.println("whatever");
    }

    @When("^the user create a list$")
    public void theUserCreateAList() throws MalformedURLException {
        String name = getRandomString(3);
        DataSession.setInSession(DataSession.Data.NAME, name);
        response = requestSpecification.when().post(TestController.createList());

    }

    @And("^the list has been created$")
    public void theListHasBeenCreated() {

    }

    public String getterMembers(int a) throws MalformedURLException {
        response = requestSpecification.when().get(TestController.getIDMembers());

        members = gson.fromJson(response.body().asString(), Members[].class);
        String id = members[a].getId();

        return id;
    }
}
