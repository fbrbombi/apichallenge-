package utils;

import org.apache.commons.lang3.RandomStringUtils;

public class RandomVaraibles {

    public static String getRandomString(int size) {
        return RandomStringUtils.randomAlphanumeric(size);
    }
}
