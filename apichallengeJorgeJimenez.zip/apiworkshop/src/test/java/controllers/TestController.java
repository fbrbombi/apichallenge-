package controllers;

import com.google.gson.JsonObject;
import com.jayway.jsonpath.JsonPath;
import utils.DataSession;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class TestController {
    private static final String KEY = "0149e97b1f17867ccb1d1841865f76a7";
    private static final String TOKEN = "a101de921fd9de2320ec982d7f5253f0b524abafca63b2aebf80ca0d3559f27a";
    private static final String CONTENT_TYPE = "";
//    private String listToAddTheNewCard;
    private static final String IDBOARD = "5c48d85de5f8a01996d278ac";
//    public static final String nameTODO = "to do jorge ";
//    private static final String descTODO = "jorge";
    private static final String idListTODO = "5c48df6f2217f65db47d41e3";
    private static final String idListINPROGRESS = "5c759df32a97877c31e386d9";
    private static final String idListDONE = "5c769a72d2dc292cd6554c3a";
//    private static final String idcardTODO = "5c744228cbd3ef6740ad3fba";
    private static final String idCarla = "5c700c69ad6f486df2fa561b";
    private static final String baseUrl = "https://api.trello.com/1/cards";


    public static String getBaseUrl() {
        return baseUrl;
    }

    public static Map<String, String> getAuthParams() {
        Map<String, String> params = new HashMap<>();
        params.put("key", KEY);
        params.put("token", TOKEN);
        return params;
    }

    public static URL getlistsInBoards() throws MalformedURLException {
        return new URL("https://api.trello.com/1/boards/" + IDBOARD + "/lists");
    }

    public static String postCreateCard() throws MalformedURLException {
        String name = (String) DataSession.getFromSession(DataSession.Data.NAME);
        String description = (String) DataSession.getFromSession(DataSession.Data.DESCRIPTION);

        String url = "?name=" + name + "&desc=" + description + "&idList=" + idListTODO + "&keepFromSource=all";

        return url;

    }

    public static URL postAddMembers(String id) throws MalformedURLException {

        String IDLISTTODO = (String) DataSession.getFromSession(DataSession.Data.IDCARD);
        return new URL("https://api.trello.com/1/cards/" + IDLISTTODO + "/idMembers?value=" + id + "&key=" + KEY + "&token=" + TOKEN + "");

    }

    public static URL postAddComent() throws MalformedURLException {
        String IDCARD = (String) DataSession.getFromSession(DataSession.Data.IDCARD);
        String COMMENT = (String) DataSession.getFromSession(DataSession.Data.COMMENT);
        return new URL("https://api.trello.com/1/cards/" + IDCARD + "/actions/comments?text=" + COMMENT + "");
    }

    public static String putMoveCardProgress() throws MalformedURLException {
        String idCard = DataSession.getFromSession(DataSession.Data.IDCARD).toString().trim();
        String url = "/" + idCard + "?idList=" + idListINPROGRESS;
        return url;

    }
    public static String putMoveCardDone() throws MalformedURLException {
        String idCard = DataSession.getFromSession(DataSession.Data.IDCARD).toString().trim();
        String url = "/" + idCard + "?idList=" + idListDONE;
        return url;

    }
    public static String deleteCard()throws MalformedURLException{
        String idCard = DataSession.getFromSession(DataSession.Data.IDCARD).toString().trim();
        String url = "/" + idCard ;
        return url;
    }

    public static URL createList()throws  MalformedURLException{
        String name = DataSession.getFromSession(DataSession.Data.NAME).toString().trim();
        return new URL("https://api.trello.com/1/lists?name="+name+"&idBoard="+IDBOARD);
    }

    public static URL getIDMembers() throws  MalformedURLException{
        return new URL("https://api.trello.com/1/boards/"+IDBOARD+"/members");
    }
}
