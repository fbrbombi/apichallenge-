package controllers;


import com.jayway.jsonpath.JsonPath;
import io.restassured.response.Response;
import net.thucydides.core.steps.ScenarioSteps;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class TestController extends ScenarioSteps {

    private static final String KEY="36bd0d2a46f5bb2cd844aca9f8f05dfb";
    private static final String TOKEN="be48f06a7deeba67c7c5271e25983d119d703e677df086c765533a1356c8f4cf";
    private static final String NAME="This is a name";
    private static final String NAMELIST="Q/A";
    private static final String DESCRIPTION="This is the description";
    private static final String COMMENT="This is a comment skljdjlksjdkl";

    public Map<String,String> getAuthParams(){
        Map<String,String> params= new HashMap<>();
        params.put("key", KEY);
        params.put("token", TOKEN);
        return params;
    }

    public String getIdBoard(Response response)
    {
        String jsonString = response.getBody().asString();
        String boardId="";
        int length =  com.jayway.jsonpath.JsonPath.read(jsonString,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = com.jayway.jsonpath.JsonPath.read(jsonString, "$.["+i+"].name");
            if(name.equals("API Challenge 19")){
                boardId = JsonPath.read(jsonString, "$.["+i+"].id");
                return boardId;
            }
        }
        return boardId;
    }


    public String getIdCard(Response response)
    {
        String jsonString = response.getBody().asString();
        String cardId="";
        int length =  com.jayway.jsonpath.JsonPath.read(jsonString,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = com.jayway.jsonpath.JsonPath.read(jsonString, "$.["+i+"].name");
            if(name.equals("This is a name")){
                cardId = JsonPath.read(jsonString, "$.["+i+"].id");
                return cardId;
            }

        }
        return cardId;
    }
    public String getIdMember(Response response)
    {
        String jsonString = response.getBody().asString();
        System.out.println("PARCE ESTO ES EL RESPONSE  "+response);
        System.out.println("PARCE ESTO ES EL JSONSTRING  "+jsonString);
        String memberId="";
        int length =  com.jayway.jsonpath.JsonPath.read(jsonString,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = com.jayway.jsonpath.JsonPath.read(jsonString, "$.["+i+"].username");
            if(name.equals("camilavanegas1")){
                memberId = JsonPath.read(jsonString, "$.["+i+"].id");
                System.out.println("PARCE ESTO ES EL member id  "+memberId );
                return memberId;
            }

        }
        return memberId;
    }
    public String getIdList(Response response)
    {
        String jsonString = response.getBody().asString();
        System.out.println(response);
        System.out.println(jsonString);
        String listId="";
        int length =  com.jayway.jsonpath.JsonPath.read(jsonString,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = com.jayway.jsonpath.JsonPath.read(jsonString, "$.["+i+"].name");
            if(name.equals("TODO")){
                listId = JsonPath.read(jsonString, "$.["+i+"].id");
                return listId;
            }
        }
        return listId;
    }
    public String getIdNewList(Response response)
    {
        String jsonString = response.getBody().asString();
        System.out.println(response);
        System.out.println(jsonString);
        String listId="";
        int length =  com.jayway.jsonpath.JsonPath.read(jsonString,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = com.jayway.jsonpath.JsonPath.read(jsonString, "$.["+i+"].name");
            if(name.equals("IN PROGRESS")){
                listId = JsonPath.read(jsonString, "$.["+i+"].id");
                return listId;
            }
        }
        return listId;
    }
    public String getIdNewNewList(Response response)
    {
        String jsonString = response.getBody().asString();
        System.out.println(response);
        System.out.println(jsonString);
        String listId="";
        int length =  com.jayway.jsonpath.JsonPath.read(jsonString,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = com.jayway.jsonpath.JsonPath.read(jsonString, "$.["+i+"].name");
            if(name.equals("DONE")){
                listId = JsonPath.read(jsonString, "$.["+i+"].id");
                return listId;
            }
        }
        return listId;
    }
    public URL getListsInBoardUrl(String BOARD) throws MalformedURLException {
        return  new URL("https://api.trello.com/1/boards/"+BOARD+"/lists");
    }
    public URL getCardsInList(String TODO_LIST) throws MalformedURLException {
        return  new URL("https://api.trello.com/1/lists/"+TODO_LIST+"/cards?fields=id,name,badges,labels");
    }
    public URL postCardInListUrl(String TODO_LIST) throws MalformedURLException {
        return  new URL("https://api.trello.com/1/cards?name="+NAME+"&desc="+DESCRIPTION+"&idList="+TODO_LIST+"&keepFromSource=all&key="+KEY+"&token="+TOKEN);
    }
    public URL postCommentInCard(String CARD_ID)throws MalformedURLException{
        return  new URL("https://api.trello.com/1/cards/"+CARD_ID+"/actions/comments?text="+COMMENT+"&key="+KEY+"&token="+TOKEN);
    }
    public URL getMembersInBoard(String BOARD) throws MalformedURLException {
        return  new URL("https://api.trello.com/1/boards/"+BOARD+"/members?key="+KEY+"&token="+TOKEN+"&fields=username");
    }
    public URL postMemberInCard(String CARD_ID,String ID_MEMBER)throws MalformedURLException{
        return  new URL("https://api.trello.com/1/cards/"+CARD_ID+"/idMembers?value="+ID_MEMBER+"&key="+KEY+"&token="+TOKEN);
    }

    public URL putMoveCard(String CARD_ID,String NEW_LIST)throws MalformedURLException{
        return  new URL("https://api.trello.com/1/cards/"+CARD_ID+"/idList?value="+NEW_LIST+"&key="+KEY+"&token="+TOKEN);
    }
    public URL deleteCardInList(String CARD_ID)throws MalformedURLException{
        return  new URL("https://api.trello.com/1/cards/"+CARD_ID+"?key="+KEY+"&token="+TOKEN);
    }
    public String getPosList(Response response)throws MalformedURLException
    {
        String jsonString = response.getBody().asString();
        String listPos2="";
        int listPos;
        int length =  com.jayway.jsonpath.JsonPath.read(jsonString,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = com.jayway.jsonpath.JsonPath.read(jsonString, "$.["+i+"].name");
            if(name.equals("IN PROGRESS")){
                listPos = JsonPath.read(jsonString, "$.["+i+"].pos");
                int pos = listPos + 1;
                listPos2 =String.valueOf(pos);
                return listPos2;
            }
        }
        return listPos2;
    }
    public String getIdAddedList(Response response)
    {
        String jsonString = response.getBody().asString();
        System.out.println(response);
        System.out.println(jsonString);
        String listId="";
        int length =  com.jayway.jsonpath.JsonPath.read(jsonString,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = com.jayway.jsonpath.JsonPath.read(jsonString, "$.["+i+"].name");
            if(name.equals("Q/A")){
                listId = JsonPath.read(jsonString, "$.["+i+"].id");
                return listId;
            }
        }
        return listId;
    }
    public URL postListInBoard(String BOARD)throws MalformedURLException{
        return  new URL("https://api.trello.com/1/lists?name="+NAMELIST+"&idBoard="+BOARD+"&token="+TOKEN);
    }
    public URL putMoveListInBoard(String LIST_ID,String POS)throws MalformedURLException{
        return  new URL("https://api.trello.com/1/lists/"+LIST_ID+"/pos?value="+POS+"&key="+KEY+"&token="+TOKEN);
    }

}
