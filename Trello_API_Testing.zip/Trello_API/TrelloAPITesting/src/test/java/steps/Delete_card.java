package steps;

import controllers.TestController;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;

import java.net.MalformedURLException;

public class Delete_card {
    private String id_board= new String();
    private String id_list= new String();
    private String id_card= new String();

    @Steps
    private TestController testController;
    private RequestSpecification requestSpecification;
    private Response response;

    @Given("^A logged user in a board in Trello Web Page$")
    public void aLoggedUserInABoardInTrello() {
        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }
    @When("^He clicks on a card in a list$")
    public void heClicksOnTheCard(){
        response=requestSpecification.when().get("https://api.trello.com/1/members/me/boards");
        id_board=testController.getIdBoard(response);
        String assert1 = id_board;
        Assert.assertEquals("5c48d85de5f8a01996d278ac", assert1);
        try {
            response=requestSpecification.when().get(testController.getListsInBoardUrl(id_board));
            id_list=testController.getIdNewNewList(response);
            String assert2 = id_list;
            Assert.assertEquals("5c769a72d2dc292cd6554c3a", assert2);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

        try {
            response=requestSpecification.when().get(testController.getCardsInList(id_list));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        id_card=testController.getIdCard(response);
    }

    @And("^He clicks the Archive action button$")
    public void heClicksTheArchiveActionButton() {
    }

    @And("^He clicks the Delete action button$")
    public void heClicksTheDeleteActionButton() {

        try {
            response=requestSpecification.when().delete(testController.deleteCardInList(id_card));
            Assert.assertEquals(200, response.getStatusCode());
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

    }

    @Then("^The card is deleted from the list$")
    public void theCardIsDeletedFromTheList() {
    }


}
