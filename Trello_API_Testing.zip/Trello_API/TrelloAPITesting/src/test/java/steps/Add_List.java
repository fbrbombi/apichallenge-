package steps;

import controllers.TestController;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;

import java.net.MalformedURLException;

public class Add_List {
    private String id_board= new String();
    private String id_list= new String();
    private String list_value= new String();
    @Steps
    private TestController testController;
    private RequestSpecification requestSpecification;
    private Response response;

    @Given("^A logged user is on a board in Trello Web Page$")
    public void aLoggedUserIsInTrelloWebPage() {
        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());

        response=requestSpecification.when().get("https://api.trello.com/1/members/me/boards");
        id_board=testController.getIdBoard(response);
        String assert1 = id_board;
        Assert.assertEquals("5c48d85de5f8a01996d278ac", assert1);
    }

    @When("^He clicks on a Add another list button$")
    public void heClicksOnAAddAnotherListButton() {

    }

    @And("^Enters the list title$")
    public void entersTheListTitle() {
    }

    @And("^Clicks the Add List button$")
    public void clicksTheAddListButton() throws Throwable {

        response= requestSpecification.when().post(testController.postListInBoard(id_board));

    }

    @And("^Drags the list to its new position$")
    public void dragsTheListToItsNewPosition() throws Throwable {
        response= requestSpecification.when().get(testController.getListsInBoardUrl(id_board));
        id_list=testController.getIdAddedList(response);
        list_value=testController.getPosList(response);

    }

    @Then("^A new list is added to the board in a specific position$")
    public void aNewListIsAddedToTheBoardInASpecificPosition()  {
        try {
            response=requestSpecification.when().put(testController.putMoveListInBoard(id_list,list_value));
            Assert.assertEquals(200, response.getStatusCode());
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

    }
}
