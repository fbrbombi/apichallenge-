package steps;

import controllers.TestController;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.internal.assertion.Assertion;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;

import java.net.MalformedURLException;

public class Update_card {
    private String id_board= new String();
    private String id_list= new String();
    private String id_card= new String();
    private String id_member= new String();

    @Steps
    private TestController testController;
    private RequestSpecification requestSpecification;
    private Response response;
    @Given("^A logged user is in Trello Web page$")
    public void aLoggedUserIsInTrelloWebPage() {
        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
        response=requestSpecification.when().get("https://api.trello.com/1/members/me/boards");
        id_board=testController.getIdBoard(response);
        String assert1 = id_board;
        Assert.assertEquals("5c48d85de5f8a01996d278ac", assert1);
        try {
            response= requestSpecification.when().get(testController.getListsInBoardUrl(id_board));
            id_list=testController.getIdList(response);
            String assert2 = id_list;
            Assert.assertEquals("5c48df6f2217f65db47d41e3", assert2);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

    }

    @When("^He clicks the card$")
    public void heClicksTheCard() throws Throwable {
        response=requestSpecification.when().get(testController.getCardsInList(id_list));
        id_card=testController.getIdCard(response);
    }

    @And("^Writes the first comment$")
    public void writeAComment() {
    }

    @And("^Clicks on Save button$")
    public void clicksOnSaveButton() throws Throwable{
        response= requestSpecification.when().post(testController.postCommentInCard(id_card));
    }

    @Then("^The comment is added to the card$")
    public void theCommentIsAddedToTheCard() {
    }
//=============================================================
    @And("^Clicks on add members to the card$")
    public void clicksOnAddMembersToTheCard() {
        
    }

    @And("^Search an existing member on the board$")
    public void searchAnExistingMemberOnTheBoard() {
        
    }

    @And("^Selects it$")
    public void selectsIt() throws Throwable{
        response=requestSpecification.when().get(testController.getCardsInList(id_list));
        id_card=testController.getIdCard(response);
        response=requestSpecification.when().get(testController.getMembersInBoard(id_board));
        id_member=testController.getIdMember(response);
    }

    @Then("^The member is added to the card$")
    public void theMemberIsAddedToTheCard()  {
        try {
            response= requestSpecification.when().post(testController.postMemberInCard(id_card,id_member));
            Assert.assertEquals(200, response.getStatusCode());
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

    }
//====================================================================
    @When("^The user drags the card to the IN PROGRESS list$")
    public void theUserDragsTheCardToTheINPROGRESSListNew()  {
        response=requestSpecification.when().get("https://api.trello.com/1/members/me/boards");
        id_board=testController.getIdBoard(response);
        String assert1 = id_board;
        Assert.assertEquals("5c48d85de5f8a01996d278ac", assert1);
        try {
            response= requestSpecification.when().get(testController.getListsInBoardUrl(id_board));
            id_list=testController.getIdList(response);
            String assert2 = id_list;
            Assert.assertEquals("5c48df6f2217f65db47d41e3", assert2);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

        try {
            response=requestSpecification.when().get(testController.getCardsInList(id_list));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        id_card=testController.getIdCard(response);
        try {
            response=requestSpecification.when().get(testController.getListsInBoardUrl(id_board));
            id_list=testController.getIdNewList(response);
            String assert3 = id_list;
            Assert.assertEquals("5c759df32a97877c31e386d9", assert3);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

    }

    @Then("^The card is added to the IN PROGRESS list$")
    public void theCardIsAddedToTheINPROGRESSList() {
        try {
            response=requestSpecification.when().put(testController.putMoveCard(id_card,id_list));
            Assert.assertEquals(200, response.getStatusCode());
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

    }

    //====================================================================
    @And("^Writes a second comment$")
    public void writesASecondComment()  {
        response=requestSpecification.when().get("https://api.trello.com/1/members/me/boards");
        id_board=testController.getIdBoard(response);
        String assert1 = id_board;
        Assert.assertEquals("5c48d85de5f8a01996d278ac", assert1);
        try {
            response= requestSpecification.when().get(testController.getListsInBoardUrl(id_board));
            id_list=testController.getIdNewList(response);
            String assert2 = id_list;
            Assert.assertEquals("5c759df32a97877c31e386d9", assert2);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

        try {
            response=requestSpecification.when().get(testController.getCardsInList(id_list));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        id_card=testController.getIdCard(response);

        try {
            response= requestSpecification.when().post(testController.postCommentInCard(id_card));
            Assert.assertEquals(200, response.getStatusCode());
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

    }

    @And("^Clicks on the Save button$")
    public void clicksOnTheSaveButton() {
    }
//==============================================================
    @When("^The user drags the card to the DONE list$")
    public void theUserDragsTheCardToTheDONEListNew()  {
        response=requestSpecification.when().get("https://api.trello.com/1/members/me/boards");
        id_board=testController.getIdBoard(response);
        String assert1 = id_board;
        Assert.assertEquals("5c48d85de5f8a01996d278ac", assert1);
        try {
            response= requestSpecification.when().get(testController.getListsInBoardUrl(id_board));
            id_list=testController.getIdNewList(response);
            String assert2 = id_list;
            Assert.assertEquals("5c759df32a97877c31e386d9", assert2);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

        try {
            response=requestSpecification.when().get(testController.getCardsInList(id_list));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        id_card=testController.getIdCard(response);


        try {
            response=requestSpecification.when().get(testController.getListsInBoardUrl(id_board));
            id_list=testController.getIdNewNewList(response);
            String assert3 = id_list;
            Assert.assertEquals("5c769a72d2dc292cd6554c3a", assert3);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }
    }

    @Then("^The card is added to the DONE list$")
    public void theCardIsAddedToTheDONEList() {
        try {
            response=requestSpecification.when().put(testController.putMoveCard(id_card,id_list));
            Assert.assertEquals(200, response.getStatusCode());
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

    }
//====================================================================
    @And("^Writes a final comment$")
    public void writesAFinalComment() {

    }

    @And("^Clicks the Save button$")
    public void clicksTheSaveButton() {
        response=requestSpecification.when().get("https://api.trello.com/1/members/me/boards");
        id_board=testController.getIdBoard(response);
        String assert1 = id_board;
        Assert.assertEquals("5c48d85de5f8a01996d278ac", assert1);

        try {
            response= requestSpecification.when().get(testController.getListsInBoardUrl(id_board));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        id_list=testController.getIdNewNewList(response);


        try {
            response=requestSpecification.when().get(testController.getCardsInList(id_list));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        id_card=testController.getIdCard(response);

        try {
            response= requestSpecification.when().post(testController.postCommentInCard(id_card));
            Assert.assertEquals(200, response.getStatusCode());
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

    }
}
