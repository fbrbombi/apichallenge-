package steps;

import controllers.TestController;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;

import java.net.MalformedURLException;

public class Get_list {
    private String id_board= new String();

    @Steps
    private TestController testController;
    private RequestSpecification requestSpecification;
    private Response response;

    @Given("^A logged user is on Trello Web page$")
    public void aLoggedUserIsInTrelloWebPage() {
        requestSpecification= RestAssured.given().contentType("application/json")
                .and().queryParams(testController.getAuthParams());
    }

    @When("^He goes to the board$")
    public void heGoesToTheBoard(){
        response=requestSpecification.when().get("https://api.trello.com/1/members/me/boards");
        id_board=testController.getIdBoard(response);
        String assert1 = id_board;
        Assert.assertEquals("5c48d85de5f8a01996d278ac", assert1);


    }

    @Then("^The lists are displayed$")
    public void theListsAreDisplayed() {
        try {
            response= requestSpecification.when().get(testController.getListsInBoardUrl(id_board));
            Assert.assertEquals(200, response.getStatusCode());
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Assert.fail();
        }

    }
}
