package controllers;

import com.jayway.jsonpath.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utils.Constants;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class GetTestController extends TestController{

    private static GetTestController getTestControllerInstance;

    private GetTestController(){}

    public static GetTestController GetTestControllerInstance() {
        if(getTestControllerInstance == null)
            getTestControllerInstance = new GetTestController();
        return getTestControllerInstance;
    }

    public URL getBoardsURL(String userId) throws MalformedURLException {
        return new URL("https://api.trello.com/1/members/"+ userId +"/boards");
    }

    public URL getListsURL(String boardId) throws MalformedURLException {
        return new URL("https://api.trello.com/1/boards/"+boardId+"/lists");
    }

    public URL getCardsURL(String listId) throws MalformedURLException {
        return new URL("https://api.trello.com/1/lists/"+ listId +"/cards");
    }

    public URL getBoardMembersURL(String boardId) throws MalformedURLException {
        return new URL("https://api.trello.com/1/boards/"+boardId+"/members");
    }

    public URL getCardMembersURL(String cardId) throws MalformedURLException {
        return new URL("https://api.trello.com/1/cards/"+cardId+"/members");
    }

    public Response getBoards(RequestSpecification requestSpecification, String userId){
        Response response = null;
        try {
            response = requestSpecification.and().get(this.getBoardsURL(userId));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return response;
    }

    public String getBoardId(RequestSpecification requestSpecification, String boardName){
        Response response = getBoards(requestSpecification, getUserId(requestSpecification));
        String sJson = response.getBody().asString();
        int length =  JsonPath.read(sJson,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = JsonPath.read(sJson, "$.["+i+"].name");
            if(name.equals(boardName)){
                String boardId = JsonPath.read(sJson, "$.["+i+"].id");
                return boardId;
            }
        }
        System.out.println("There are not boards with that name: " + boardName);
        return null;
    }

    public Response getListsOfBoard(RequestSpecification requestSpecification, String boardId){
        Response response = null;
        try {
            response = requestSpecification.and().get(this.getListsURL(boardId));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return response;
    }

    public String getListId(RequestSpecification requestSpecification, String listName){
        String boardId = getBoardId(requestSpecification, Constants.BOARD);
        Response response = getListsOfBoard(requestSpecification, boardId);
        String sJson = response.getBody().asString();
        int length =  JsonPath.read(sJson,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = JsonPath.read(sJson, "$.["+i+"].name");
            if(name.equals(listName)){
                String listId = JsonPath.read(sJson, "$.["+i+"].id");
                return listId;
            }
        }
       //System.out.println("There are not lists with that name: " + listName);
        return null;
    }

    public Response getCards(RequestSpecification requestSpecification, String listId){
        Response response = null;
        try {
            response = requestSpecification.and().get(this.getCardsURL(listId));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return response;
    }

    public String getCardId(RequestSpecification requestSpecification, String cardName, String listName){
        String listId = getListId(requestSpecification, listName);
        Response response = getCards(requestSpecification, listId);
        String sJson = response.getBody().asString();
        int length =  JsonPath.read(sJson,"$.length()");
        for (int i=0; i< length; i++ ){
            String name = JsonPath.read(sJson, "$.["+i+"].name");
            if(name.equals(cardName)){
                String cardId = JsonPath.read(sJson, "$.["+i+"].id");
                return cardId;
            }
        }
        //System.out.println("There are not cards with that name: " + cardName);
        return null;
    }

    public Response getBoardMembers(RequestSpecification requestSpecification, String boardId){
        Response response = null;
        try {
            response = requestSpecification.and().get(this.getBoardMembersURL(boardId));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return response;
    }

    public Response getCardMembers(RequestSpecification requestSpecification, String cardId){
        Response response = null;
        try {
            response = requestSpecification.and().get(this.getCardMembersURL(cardId));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return response;
    }

    public String getRandomMember(RequestSpecification requestSpecification, String boardId, String cardId){
        Response responseBoard = getBoardMembers(requestSpecification, boardId);
        Response responseCard = getCardMembers(requestSpecification, cardId);

        String boardJson = responseBoard.getBody().asString();
        List<String> memberBoardIdList = new ArrayList<>();
        int length =  JsonPath.read(boardJson,"$.length()");
        for (int i=0; i< length; i++ ){
            String boardMemberId = JsonPath.read(boardJson, "$.["+i+"].id");
            memberBoardIdList.add(boardMemberId);
        }
        if(memberBoardIdList.isEmpty())
            System.out.println("There are not members in the board: " + Constants.BOARD);
        else{
            String cardJson = responseCard.getBody().asString();
            List<String> memberCardIdList = new ArrayList<>();
            length =  JsonPath.read(cardJson,"$.length()");
            for (int i=0; i< length; i++ ){
                String cardMemberId = JsonPath.read(boardJson, "$.["+i+"].id");
                memberCardIdList.add(cardMemberId);
            }
            if (memberCardIdList.isEmpty())
                return memberBoardIdList.get(0);
            else {
                for (String bMember : memberBoardIdList) {
                    if (!memberCardIdList.contains(bMember))
                        return bMember;
                }
            }
        }
        System.out.println("There are not members to add. Board: " + Constants.BOARD);
        return null;
    }
}
