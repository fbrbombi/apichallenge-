package controllers;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utils.Constants;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class PutTestController extends TestController{

    private static PutTestController putTestControllerInstance;

    private PutTestController(){}

    public static PutTestController PutTestControllerInstance(){
        if(putTestControllerInstance == null)
            putTestControllerInstance = new PutTestController();
        return  putTestControllerInstance;
    }

    public URL moveCardURL(String cardId) throws MalformedURLException {
        return new URL("https://api.trello.com/1/cards/" + cardId);
    }

    public Map<String, String> moveCardParams(String listId){
        Map<String, String> params = new HashMap<>();
        params.put("idList", listId);
        return params;
    }

    public RequestSpecification moveCardAuthenticate(String listId){
        Map<String, String> putPrams = moveCardParams(listId);
        Map<String, String> authPrams = getAuthParams();
        putPrams.putAll(authPrams);
        return RestAssured.given().contentType(Constants.CONTENT_TYPE)
                .and().queryParams(putPrams);
    }

    public Response moveCard(RequestSpecification requestSpecification, String cardName, String listName1){
        String cardId = GetTestController.GetTestControllerInstance().getCardId(requestSpecification, cardName, listName1);
        Response response = null;
        try {
            response = requestSpecification.and().put(moveCardURL(cardId));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return response;
    }

    public RequestSpecification moveCardRequestSpecification(RequestSpecification requestSpecification, String cardName, String listName1, String listName2){
        requestSpecification = PostTestController.PostTestControllerInstance().newVerifyListId(requestSpecification, listName1);
        requestSpecification = PostTestController.PostTestControllerInstance().newVerifyListId(requestSpecification, listName2);
        requestSpecification = PostTestController.PostTestControllerInstance().verifyCardId(requestSpecification, cardName, listName1);
        String listId2 = GetTestController.GetTestControllerInstance().getListId(requestSpecification, listName2);;
        requestSpecification = moveCardAuthenticate(listId2);
        return requestSpecification;
    }

}
