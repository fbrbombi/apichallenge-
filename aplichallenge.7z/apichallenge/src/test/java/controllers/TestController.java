package controllers;

import cucumber.api.java.Before;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.steps.ScenarioSteps;
import utils.Constants;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class TestController extends ScenarioSteps {

    private JsonPath jsonPath;

    public Map<String, String> getAuthParams(){
        Map<String, String> params = new HashMap<>();
        params.put("key", Constants.KEY);
        params.put("token", Constants.TOKEN);
        return params;
    }

    public URL getUserIdURL() throws MalformedURLException {
        return new URL("https://api.trello.com/1/tokens/"+ Constants.TOKEN);
    }

    public RequestSpecification authenticate(){
        return RestAssured.given().contentType(Constants.CONTENT_TYPE)
                .and().queryParams(getAuthParams());
    }

    public String getUserId(RequestSpecification r){
        try {
            jsonPath = (r.when().get(getUserIdURL())).jsonPath();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return jsonPath.get("idMember");
    }

}
