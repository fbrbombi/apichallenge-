package controllers;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.net.MalformedURLException;
import java.net.URL;

public class DeleteTestController extends  TestController{

    private static DeleteTestController deleteTestControllerInstance;

    private DeleteTestController(){}

    public static DeleteTestController DeleteTestControllerInstance(){
        if(deleteTestControllerInstance == null)
            deleteTestControllerInstance = new DeleteTestController();
        return deleteTestControllerInstance;
    }

    public URL deleteCardURL(String cardId) throws MalformedURLException {
        return new URL("https://api.trello.com/1/cards/" + cardId);
    }

    public Response deleteCard(RequestSpecification requestSpecification, String cardId){
        Response response = null;
        try {
            response = requestSpecification.and().delete(deleteCardURL(cardId));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return response;
    }

    public RequestSpecification deleteCardRequestSpecification(RequestSpecification requestSpecification, String cardName, String listName){
        requestSpecification = PostTestController.PostTestControllerInstance().newVerifyListId(requestSpecification, listName);
        requestSpecification = PostTestController.PostTestControllerInstance().verifyCardId(requestSpecification, cardName, listName);
        return requestSpecification;
    }

}
