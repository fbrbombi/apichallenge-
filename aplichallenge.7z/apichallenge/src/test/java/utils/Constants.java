package utils;

public class Constants {
    public static String KEY = "d8ed589332b96e598f0b6c90c79ea0c7";
    public static String TOKEN = "2543e6a4ab0b24e39074ed0efcc661ff7df7e083ac3f7d35a862d537e7f6d977";
    public static String CONTENT_TYPE = "application/json";
    public static String BOARD = "API Challenge 19";
    //public static String NEW_LIST = "NEW LIST";
    //public static String TODO_LIST = "TODO";
    //public static String IN_PROGRESS_LIST = "IN PROGRESS";
    //public static String DONE_LIST = "DONE";
    //public static String NEW_CARD = "MI TARJETA NUEVA";
    //public static String TEST_DELETE_TARJETA = "MI TARJETA A BORRAR";
    //public static String TODO_COMMENT = "TODO COMMENT";
    //public static String IN_PROGRESS_COMMENT = "IN PROGRESS COMMENT";
    //public static String DOME_COMMENT = "DONE COMMENT";
}
